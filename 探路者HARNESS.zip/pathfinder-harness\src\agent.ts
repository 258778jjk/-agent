/**
 * agent —— 核心循环（感知-规划-行动-观察）。
 *
 * 每回合：
 *   感知  组装 system prompt（persona + 长期记忆/偏好 + 当前计划进度）+ 自动摘要超长上下文
 *   规划  planner.ensurePlan 把请求分解为分步计划（Plan-and-Execute）
 *   行动  按优先级取步骤 → 流式 LLM 调用（带工具）→ 工具并行执行（权限审批）
 *   观察  反思每步行动 → 失败自动修正（回喂失败上下文重试）→ 仍失败重规划或跳过
 *   收尾  反思晋升长期记忆、优雅降级（超时/错误/中断）
 *
 * 支持：AbortSignal 中断（流式已生成内容保留）、LLM 错误重试、mock 模式。
 */

import { Session, textOf, type ContentBlock, type ToolResultBlock } from './session.ts'
import { estimateSessionTokens, maybeSummarize, summarizeInstruction } from './context.ts'
import { Planner, type Plan } from './planner.ts'
import { reflectAction, correctionPrompt, looksInvalid } from './reflection.ts'
import { executeCalls, type ToolRegistry } from './tools.ts'
import { extractFactsFromMessage, type MemoryStore } from './memory.ts'
import { chat, chatStream, LlmError, parseToolArguments, MockLlm, type LlmResponse, type LlmUsage } from './llm.ts'
import type { AgentConfig, LlmConfig } from './config.ts'

export type AgentEventType =
  | 'turn/start'
  | 'plan/created'
  | 'step/start'
  | 'assistant/message'
  | 'tool/call'
  | 'tool/result'
  | 'reflection'
  | 'correction'
  | 'context/summarized'
  | 'step/end'
  | 'turn/end'
  | 'error'
  | 'interrupted'

export interface AgentEvent {
  type: AgentEventType
  turn: number
  step?: number
  detail?: unknown
}

export interface AgentHooks {
  onEvent: (event: AgentEvent) => void
  onDelta: (text: string) => void
  askApproval: (name: string, args: Record<string, unknown>) => Promise<boolean>
}

export interface AgentRunOptions {
  session: Session
  config: AgentConfig
  llm: LlmConfig
  tools: ToolRegistry
  memory: MemoryStore
  hooks: AgentHooks
  signal?: AbortSignal
  mockLlm?: MockLlm
  /** 每次消息落盘后立即持久化会话 */
  persist?: () => void
  /** 文件工具工作区根目录 */
  workspaceRoot: string
}

export interface TurnResult {
  text: string
  steps: number
  usage?: LlmUsage
  interrupted: boolean
  plan?: Plan
}

const TURN_NUMBER = 1

/** 组装 system prompt：persona + 记忆块 + 计划进度。 */
export function buildSystemPrompt(persona: string, memoryBlock: string, planText: string): string {
  const parts = [persona]
  if (memoryBlock.trim() !== '') parts.push(memoryBlock)
  if (planText.trim() !== '') parts.push(planText)
  return parts.join('\n\n')
}

function wireRequest(
  options: AgentRunOptions,
  system: string,
  messages: import('./llm.ts').WireMessage[],
  tools: boolean,
  signal?: AbortSignal,
): import('./llm.ts').ChatRequest {
  const { llm } = options
  return {
    baseURL: llm.baseURL,
    apiKey: llm.apiKey,
    model: llm.model,
    system,
    messages,
    tools: tools ? options.tools.schemas() : undefined,
    maxTokens: llm.maxTokens,
    timeoutMs: llm.timeoutMs,
    temperature: llm.temperature,
  }
}

/** LLM 调用 + 重试（最多 retries 次）+ 优雅降级。stream=false 时内部调用不转发流式文本。 */
async function callLlmWithRetry(
  options: AgentRunOptions,
  system: string,
  messages: import('./llm.ts').WireMessage[],
  tools: boolean,
  signal?: AbortSignal,
  retries = 2,
  stream = true,
): Promise<LlmResponse> {
  const request = wireRequest(options, system, messages, tools, signal)
  let lastError: unknown
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      if (options.llm.provider === 'mock' || options.mockLlm) {
        const mock = options.mockLlm ?? new MockLlm([{ content: '（mock）任务已完成。', chunkSize: 12 }])
        return await mock.complete(request, stream ? { onDelta: (t) => options.hooks.onDelta(t) } : {}, signal)
      }
      return await chatStream(request, stream ? { onDelta: (t) => options.hooks.onDelta(t) } : {}, signal)
    } catch (error) {
      lastError = error
      if (signal?.aborted) throw error
      if (error instanceof LlmError && attempt < retries) {
        options.hooks.onEvent({ type: 'error', turn: TURN_NUMBER, detail: `LLM 错误，重试 ${attempt + 1}/${retries}: ${error.message.slice(0, 120)}` })
        await new Promise((r) => setTimeout(r, 600 * (attempt + 1)))
        continue
      }
      throw error
    }
  }
  throw lastError
}

/** 优雅降级回复（模型不可用/超时/中断时）。 */
function gracefulFallback(error: unknown, partial: string): string {
  const reason = error instanceof Error ? error.message : String(error)
  const head = `[降级模式] Agent 未能完成完整回复：${reason.slice(0, 200)}`
  return partial.trim() !== '' ? `${partial}\n\n${head}` : head
}

/**
 * 跑一个回合（感知-规划-行动-观察）。
 */
export async function runTurn(options: AgentRunOptions): Promise<TurnResult> {
  const { session, config, memory, hooks, signal } = options
  let steps = 0
  let usage: LlmUsage | undefined
  let finalText = ''
  let interrupted = false
  let plan: Plan | undefined

  hooks.onEvent({ type: 'turn/start', turn: TURN_NUMBER })

  try {
    // ---------- 感知 ----------
    // 1) 长期记忆/偏好块
    const memoryBlock = config.memory.enabled && config.memory.inject ? memory.buildMemoryBlock(config.memory.maxInjectedItems) : ''

    // 2) 上下文管理：超预算自动摘要
    const tokensBefore = estimateSessionTokens(session, config.persona)
    if (tokensBefore > config.context.tokenBudget * config.context.summarizeThreshold) {
      const result = await maybeSummarize(
        session,
        { tokenBudget: config.context.tokenBudget, summarizeThreshold: config.context.summarizeThreshold },
        config.persona,
        async (oldMessages) => {
          if (options.llm.provider === 'mock') return '[mock] 早期对话摘要：用户提出了任务并进行了多轮交流。'
          try {
            const resp = await callLlmWithRetry(options, config.persona, [{ role: 'user', content: summarizeInstruction(oldMessages) }], false, signal, 1, false)
            return resp.content
          } catch {
            return ''
          }
        },
        config.memory.shortTermTurns * 2,
      )
      if (result.summarized) hooks.onEvent({ type: 'context/summarized', turn: TURN_NUMBER, detail: `上下文压缩完成：${result.currentTokens} tokens（原 ${tokensBefore}）` })
    }

    // 3) 用户显式记忆指令（"记住…"）
    const lastUser = [...session.messages].reverse().find((m) => m.role === 'user')
    if (lastUser) {
      for (const fact of extractFactsFromMessage(textOf(lastUser))) {
        memory.addMemory('fact', fact, session.header.id, 'user-explicit')
        hooks.onEvent({ type: 'reflection', turn: TURN_NUMBER, detail: `已记住长期记忆：${fact}` })
      }
    }

    // ---------- 规划 ----------
    const planner = new Planner(config.planning, options.tools.schemas().map((t) => t.name), {
      onUpdate: (update) => {
        if (update.change === 'created') hooks.onEvent({ type: 'plan/created', turn: TURN_NUMBER, detail: update.plan })
        else hooks.onEvent({ type: 'assistant/message', turn: TURN_NUMBER, detail: update.detail })
      },
      generatePlan: async (prompt, sig) => {
        const resp = await callLlmWithRetry(options, config.persona, [{ role: 'user', content: prompt }], false, sig, 1, false)
        return resp.content
      },
    })
    const taskText = lastUser ? textOf(lastUser) : ''
    plan = await planner.ensurePlan(taskText, signal)
    const planSteps = plan.steps.length

    // ---------- 行动/观察循环 ----------
    const maxSteps = Math.max(planSteps, config.planning.maxSteps)
    let correctionsLeft = config.reflection.enabled ? config.reflection.maxCorrections : 0

    for (let step = 1; step <= maxSteps; step++) {
      if (signal?.aborted) {
        interrupted = true
        break
      }
      steps = step
      const current = planner.nextStep()
      if (!current) break
      planner.markRunning(current.id)

      hooks.onEvent({ type: 'step/start', turn: TURN_NUMBER, step, detail: { planStep: current } })

      // 组装请求：计划进度注入 system（派生状态，不落盘）
      const system = buildSystemPrompt(config.persona, memoryBlock, planner.renderForModel())
      const history = session.deriveWireMessages()
      const response = await callLlmWithRetry(options, system, history, true, signal)
      usage = response.usage ?? usage

      // 助手消息落盘
      const assistantBlocks: ContentBlock[] = []
      if (response.content.trim() !== '') assistantBlocks.push({ type: 'text', text: response.content })
      for (const call of response.toolCalls) assistantBlocks.push({ type: 'tool-call', id: call.id, name: call.name, arguments: call.arguments })
      session.append('assistant', assistantBlocks, { kind: 'model', provider: options.llm.provider, model: options.llm.model })
      options.persist?.()
      hooks.onEvent({ type: 'assistant/message', turn: TURN_NUMBER, step, detail: { text: response.content.slice(0, 200) } })

      // 输出异常检测 → 自动修正一次
      const invalidReason = looksInvalid(response.content)
      if (invalidReason && correctionsLeft > 0 && response.toolCalls.length === 0) {
        correctionsLeft--
        hooks.onEvent({ type: 'correction', turn: TURN_NUMBER, step, detail: `输出异常（${invalidReason}），触发自动修正` })
        session.append('user', [{ type: 'text', text: `[系统] 上一次输出存在问题：${invalidReason}。请修正后重新给出正确结果。` }], { kind: 'correction' })
        options.persist?.()
        continue
      }

      // 无工具调用 → 当前步骤完成
      if (response.toolCalls.length === 0) {
        planner.markDone(current.id)
        finalText = response.content
        hooks.onEvent({ type: 'step/end', turn: TURN_NUMBER, step })
        if (planner.isFinished()) break
        continue
      }

      // 工具并行执行 + 聚合
      const startedAt = Date.now()
      for (const call of response.toolCalls) {
        hooks.onEvent({ type: 'tool/call', turn: TURN_NUMBER, step, detail: { callId: call.id, name: call.name, arguments: call.arguments } })
      }
      const results = await executeCalls(
        options.tools,
        response.toolCalls,
        { workspaceRoot: options.workspaceRoot },
        hooks.askApproval,
      )

      let allOk = true
      for (const r of results) {
        hooks.onEvent({ type: 'tool/result', turn: TURN_NUMBER, step, detail: { callId: r.callId, name: r.name, ok: r.result.ok, denied: r.result.denied, output: r.result.output.slice(0, 400) } })
        const block: ToolResultBlock = { type: 'tool-result', toolCallId: r.callId, content: r.result.output, isError: !r.result.ok }
        session.append('tool', [block], { kind: 'tool', toolCallId: r.callId })
        options.persist?.()

        // 观察：反思每步行动
        if (config.reflection.enabled) {
          const entry = reflectAction({ sessionId: session.header.id, turn: TURN_NUMBER, step, action: r.name, result: r.result, elapsedMs: Date.now() - startedAt })
          memory.addReflection(entry)
          hooks.onEvent({ type: 'reflection', turn: TURN_NUMBER, step, detail: entry })
        }
        if (!r.result.ok) allOk = false
      }

      if (allOk) {
        planner.markDone(current.id)
        hooks.onEvent({ type: 'step/end', turn: TURN_NUMBER, step })
        continue
      }

      // 有失败：标记失败 → 修正或重规划
      planner.markFailed(current.id)
      if (correctionsLeft > 0) {
        correctionsLeft--
        hooks.onEvent({ type: 'correction', turn: TURN_NUMBER, step, detail: '工具执行失败，注入失败上下文请求修正' })
        const failed = results.find((r) => !r.result.ok)!
        session.append('user', [{ type: 'text', text: correctionPrompt(failed.name, parseToolArguments('{}'), failed.result.output) }], { kind: 'correction' })
        options.persist?.()
        continue
      }
      const failedStep = current
      const failedResult = results.find((r) => !r.result.ok)
      const replanned = await planner.replan(failedStep, failedResult?.result.output ?? '步骤失败', signal)
      hooks.onEvent({ type: 'correction', turn: TURN_NUMBER, step, detail: replanned ? '失败后重规划成功' : '失败且无法重规划，跳过该步骤' })
      if (!replanned) planner.markSkipped(failedStep.id)
      hooks.onEvent({ type: 'step/end', turn: TURN_NUMBER, step })
    }

    // ---------- 收尾 ----------
    if (interrupted) {
      hooks.onEvent({ type: 'interrupted', turn: TURN_NUMBER, detail: '用户中断' })
      hooks.onEvent({ type: 'turn/end', turn: TURN_NUMBER, detail: { reason: 'interrupted' } })
      return { text: finalText, steps, usage, interrupted: true, plan }
    }
    if (finalText.trim() === '' && session.messages.some((m) => m.role === 'tool')) {
      // 所有计划步骤均为工具调用：额外做一次最终合成，生成面向用户的总结
      const synthSystem = buildSystemPrompt(config.persona, memoryBlock, '')
      try {
        const synth = await callLlmWithRetry(options, synthSystem, session.deriveWireMessages(), false, signal, 1, true)
        if (synth.content.trim() !== '') {
          session.append('assistant', [{ type: 'text', text: synth.content }], { kind: 'model', provider: options.llm.provider, model: options.llm.model })
          options.persist?.()
          finalText = synth.content
        }
      } catch {
        /* 合成失败时走下方兜底 */
      }
    }
    if (finalText.trim() === '') {
      // 兜底：从最近助手文本消息取
      const last = [...session.assistantMessages()].reverse().find((m) => textOf(m).trim() !== '')
      finalText = last ? textOf(last) : '（计划执行完成，未产生文本输出）'
    }
    if (config.reflection.enabled) memory.promoteReflection(session.header.id)
    hooks.onEvent({ type: 'turn/end', turn: TURN_NUMBER, detail: { reason: 'completed', steps } })
    return { text: finalText, steps, usage, interrupted: false, plan }
  } catch (error) {
    if (signal?.aborted || (error instanceof Error && error.name === 'AbortError')) {
      hooks.onEvent({ type: 'interrupted', turn: TURN_NUMBER, detail: '用户中断' })
      hooks.onEvent({ type: 'turn/end', turn: TURN_NUMBER, detail: { reason: 'interrupted' } })
      return { text: finalText || '（已中断）', steps, usage, interrupted: true, plan }
    }
    const message = error instanceof Error ? error.message : String(error)
    hooks.onEvent({ type: 'error', turn: TURN_NUMBER, detail: message })
    const fallback = gracefulFallback(error, finalText)
    hooks.onEvent({ type: 'turn/end', turn: TURN_NUMBER, detail: { reason: 'error' } })
    return { text: fallback, steps, usage, interrupted: false, plan }
  }
}
