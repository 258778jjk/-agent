# ITERATIONS.md —— 测试与迭代记录

> 本文件记录探路者HARNESS 开发过程中的自我测试与迭代轮次。
> 每一轮遵循：运行测试 → 发现问题 → 修复 → 复测通过 → 记录效果。

测试命令（沙箱友好，单进程运行，避免子进程 EPERM）：

```bash
npm test               # 运行全部单元 + 集成 + E2E 测试
npm run test:coverage  # 附带覆盖率报告（行覆盖率 ≥ 80%）
```

---

## Round 1 —— 首次运行：TypeScript 参数属性不被支持

**发现**：`node src/main.ts ask` 启动即抛 `SyntaxError: TypeScript parameter property is not supported in strip-only mode`。

**原因**：项目采用 Node 24 原生类型剥离（strip-only）运行 TS，`constructor(private readonly x)` 这种参数属性不是「可擦除语法」。

**修复**：将 4 处参数属性（`LlmError` / `MockLlm` / `MemoryStore` / `Planner`）改为显式字段声明 + 构造器赋值。

**效果**：CLI 可正常启动，进入主流程。

---

## Round 2 —— CLI 布尔标志吞掉任务参数

**发现**：`node src/main.ts ask --mock --yes "任务..."` 报「用法: ask "任务"」，任务字符串被当作 `--yes` 的值。

**原因**：`parseArgs` 无法区分「带值标志」（`--resume`、`--port`、`--note`）与「布尔标志」（`--mock`、`--yes`）。

**修复**：引入 `valueFlags` 白名单，布尔标志不再吞下一个参数。

**效果**：`--mock --yes` 组合正常解析，demo 命令可运行。

---

## Round 3 —— 规划阶段的 mock 内容泄漏到 stdout

**发现**：mock 模式下，规划产生的计划 JSON 被打印到 stdout，污染最终答案。

**原因**：`generatePlan` 内部调用复用 `callLlmWithRetry`，mock 的流式 delta 被转发到 `hooks.onDelta`。

**修复**：给 `callLlmWithRetry` 增加 `stream` 参数，规划/摘要等内部调用传 `stream=false`，不转发文本。

**效果**：stdout 只输出最终答案，退出码 0。

---

## Round 4 —— 3 个测试失败（含 1 个真实设计缺陷）

运行完整测试套件后 3 个失败：

1. **calculator 期望值错误（测试 bug）**：断言 `/2061/`，实际 `(123*45+678)/3 = 2071`。修正断言。
2. **测试 helper 覆盖默认 onDelta（测试 bug）**：`silentHooks({ onDelta: opts?.onDelta })` 在未传时把 `undefined` 展开覆盖了默认函数。改为条件展开。
3. **真实设计缺陷 —— 缺「最终合成」步骤**：当计划的所有步骤都是工具调用时，工具执行完 `planner.nextStep()` 返回空 → 直接 break，`finalText` 为空，输出「（计划执行完成，未产生文本输出）」。

**修复（缺陷 3）**：在循环结束后，若 `finalText` 为空且会话中出现过工具消息，额外调用一次无工具的 LLM 做最终合成，生成面向用户的总结。

**效果**：49/49 测试全部通过。

---

## Round 5 —— 真实模型输出为空

**发现**：接入真实模型后，工具正常调用、usage 正常，但 stdout 无最终答案。

**原因**：真实模型走非流式 `chat()`，`onDelta` 不触发，而 CLI 仅靠 `onDelta` 打印输出。

**修复**：真实模型也改走流式 `chatStream`，并把 delta 转发到 `hooks.onDelta`（同时获得更好的 CLI 流式体验）。

**效果**：真实模型流式输出最终答案；49/49 测试仍全过。

---

## Round 6 —— 真实模型 + 反馈记忆闭环验证

**验证内容**：真实 key（七牛云）下完整跑通：

1. 复杂请求 → 计划拆解（calculator + weather 两步）→ 工具并行/顺序执行 → 反思日志 → 最终合成。
2. `feedback ... down --note "以后回答尽量简洁"` → 偏好提取入库。
3. `--resume` 恢复会话 → 长期记忆/偏好注入 system prompt → 模型行为明显改变（回复从「加粗+列表」变为一句话简洁回答）。

**效果**：52/52 测试通过（新增 3 个 E2E 用例），行覆盖率 83.8%（≥ 80%）。

---

## Round 7 —— 三项易用性改造（供应商配置 / 工作区 / 记忆单篇化）

**反馈来源**：用户验收后提出三点：
1. 前端缺「自定义模型供应商」入口（应像 DSH 一样配 Provider ID/显示名称/API 地址/协议/密钥/模型目录）
2. 前端没有让用户指定工作区
3. 记忆太零散，应做成「一篇可复制、可编辑的浓缩提示词」txt 形式

**修复**：

1. **新增 `src/runtime.ts`（RuntimeStore）**：供应商注册表 + 运行设置，持久化到 `data/providers.json` / `data/settings.json`；`resolveLlm()` 按「运行时供应商 > 环境变量/DSH > agent.yml > 默认」解析；`resolveWorkspace()` 支持前端指定工作区。
2. **记忆单篇化**：`MemoryStore` 从 JSONL 条目模型重构为 `data/memory/prompt.txt` 纯文本——每行一条（`- [事实] / [用户偏好] / [教训]`），`buildMemoryBlock()` 注入整篇；新增 `getPrompt/setPrompt/clear`。
3. **server.ts**：新增 `/api/providers`（add/remove，密钥脱敏返回）、`/api/settings`、`/api/memory`（save/clear）；LLM 与工作区改为**每请求动态解析**，运行中切换供应商/工作区即时生效。
4. **前端**：设置面板加供应商表单 + 供应商列表（使用/删除）+ 工作区 + 默认模型下拉；记忆面板改为单个 textarea（复制/保存/清空）。

**修复过程中的真实缺陷**：`RuntimeStore.addProvider` 对 id 小写归一化后，`find(p => p.id === input.id)` 用未归一化的 `input.id` 匹配，导致重复添加同名供应商不更新。→ 先归一化 id 再查找。

**效果**：66/66 测试通过（新增 runtime.test.ts 8 例 + server 供应商/设置 3 例），行覆盖率 87.15%；真实模型经「Web 供应商配置 → 聊天」链路验证通过（`12*34` → 调用 calculator → 最终合成「12 × 34 = 408」）。

---

## 当前状态

| 指标 | 值 |
|---|---|
| 测试总数 | 66 |
| 通过 | 66 |
| 失败 | 0 |
| 行覆盖率 | 87.15% |
| 分支覆盖率 | 68.59% |
| 函数覆盖率 | 89.71% |
| 真实模型 E2E | ✅ 通过（含自定义供应商链路） |

**已知边界**：`config.ts` 中 `loadDshSettings/loadDshCredentials`（读取本机 DSH 配置）与 `llm.ts` 中真实网络 SSE 解析路径，因依赖本机 `$DSH_HOME` 与外部网络，覆盖率贡献较低；其逻辑已在真实模型 E2E 中人工验证通过。

---

## 前端 E2E（Playwright）说明

用户要求的前端端到端测试已提供两套：

1. **`tests/e2e.test.ts`（可在本环境运行）**：通过 HTTP/SSE 协议层模拟完整前端交互流——发送消息 → 流式接收 → 工具调用 → 反馈 → 记忆查看/编辑 → 中断。已纳入 `npm test`，全部通过。
2. **`tests/e2e-playwright/console.spec.ts` + `playwright.config.ts`（真实浏览器）**：覆盖发送/接收/工具卡片/反馈按钮/记忆增删/桌面与移动端响应式布局。

**环境限制**：本开发沙箱禁止 `child_process` 以管道 stdio 派生子进程（`spawn EPERM`），Playwright 的浏览器下载（`playwright install`）与浏览器启动均受此限制，无法在本沙箱内运行。请在有网络的普通机器上执行：

```bash
npm run test:e2e        # 自动下载 Chromium 并运行浏览器 E2E
```

