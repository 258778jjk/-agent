/**
 * reflection —— 反思与自我修正。
 *
 * - reflectAction：每轮行动后规则式生成反思（行动是否有效、原因、调整方向）
 * - correctOnce：输出异常（格式错误/工具异常）时自动触发一次修正尝试
 *
 * 反思结果写入 MemoryStore（短期反思日志 + 可晋升为长期教训）。
 */

import { MemoryStore, type ReflectionEntry } from './memory.ts'
import type { ToolResult } from './tools.ts'

export interface ReflectionConfig {
  enabled: boolean
  maxCorrections: number
}

export interface ReflectInput {
  sessionId: string
  turn: number
  step: number
  action: string
  result: ToolResult
  elapsedMs: number
}

/** 规则式反思：分析行动是否有效、原因、调整方向。 */
export function reflectAction(input: ReflectInput): Omit<ReflectionEntry, 'id' | 'createdAt'> {
  const { action, result, elapsedMs } = input
  let reason: string
  let adjustment: string
  if (result.denied) {
    reason = '用户拒绝执行该工具'
    adjustment = '放弃此动作，改用其它方式或直接向用户说明'
  } else if (!result.ok) {
    reason = `工具返回异常：${result.output.slice(0, 120)}`
    adjustment = '修正调用参数后重试一次，或跳过此步骤继续'
  } else if (result.output.trim() === '') {
    reason = '工具返回空结果'
    adjustment = '视为无效行动，调整查询条件重试'
  } else if (result.output.length > 4000) {
    reason = `工具输出过长（${result.output.length} 字符）`
    adjustment = '结果已保留关键部分，后续引用时精炼提取'
  } else {
    reason = `行动有效（耗时 ${elapsedMs}ms）`
    adjustment = ''
  }
  return {
    sessionId: input.sessionId,
    turn: input.turn,
    step: input.step,
    action,
    ok: result.ok && !result.denied && result.output.trim() !== '',
    reason,
    adjustment,
  }
}

/** 一次修正尝试的提示词（把失败上下文回喂给模型）。 */
export function correctionPrompt(action: string, args: Record<string, unknown>, error: string): string {
  return (
    `[系统提示] 上一步动作「${action}(${JSON.stringify(args).slice(0, 200)})」失败了：\n` +
    `${error}\n` +
    `请分析失败原因并给出修正后的动作（修正参数重试、改用其它工具、或说明无法完成）。`
  )
}

/** 检测模型输出是否异常（格式/内容层面）。 */
export function looksInvalid(content: string): string | undefined {
  if (content.trim() === '') return '输出为空'
  if (/^\{.*\}$/s.test(content.trim()) && !content.includes('步骤') && !content.includes('step')) return '输出疑似未解析的 JSON'
  if (content.length > 20000) return '输出过长（可能超出限制）'
  return undefined
}

export interface ReflectionService {
  record(input: ReflectInput): Omit<ReflectionEntry, 'id' | 'createdAt'>
  promote(sessionId: string): void
}
