/**
 * config —— 分层配置解析。
 * 优先级：环境变量 > $DSH_HOME/settings.yaml / .credentials.yaml > config/agent.yml > 内置默认。
 * 可复用本机 DSH 已配置的模型供应商（settings.yaml 的 llm-pi-ai / agent-default-model）。
 */

import { homedir } from 'node:os'
import { join, resolve } from 'node:path'
import { parseYamlFile, type YamlValue } from './yaml-mini.ts'

export interface LlmConfig {
  provider: string
  baseURL: string
  apiKey: string | undefined
  model: string
  maxTokens: number
  timeoutMs: number
  temperature: number
}

export interface AgentConfig {
  persona: string
  llm: {
    provider: string
    model: string
    baseURL: string
    apiKeyEnv: string
    maxTokens: number
    timeoutMs: number
    temperature: number
  }
  tools: { enabled: string[]; requireApproval: string[]; workspaceRoot: string }
  planning: { enabled: boolean; maxSteps: number; maxReplans: number }
  reflection: { enabled: boolean; maxCorrections: number }
  memory: { enabled: boolean; inject: boolean; maxInjectedItems: number; shortTermTurns: number; maxNoteBytes: number }
  context: { tokenBudget: number; summarizeThreshold: number; maxSummarizeRetries: number }
  persistence: { dir: string }
  server: { host: string; port: number }
}

const DEFAULTS: AgentConfig = {
  persona: '你是探路者HARNESS，一个智能 Agent。先规划再执行，失败时反思并修正。',
  llm: { provider: 'auto', model: 'auto', baseURL: 'auto', apiKeyEnv: 'auto', maxTokens: 4096, timeoutMs: 120000, temperature: 0.3 },
  tools: { enabled: ['calculator', 'web_search', 'weather', 'file_read', 'file_write', 'db_query'], requireApproval: ['file_write'], workspaceRoot: './workspace' },
  planning: { enabled: true, maxSteps: 10, maxReplans: 2 },
  reflection: { enabled: true, maxCorrections: 1 },
  memory: { enabled: true, inject: true, maxInjectedItems: 10, shortTermTurns: 8, maxNoteBytes: 8192 },
  context: { tokenBudget: 8000, summarizeThreshold: 0.7, maxSummarizeRetries: 1 },
  persistence: { dir: './data' },
  server: { host: '127.0.0.1', port: 3088 },
}

function str(v: YamlValue | undefined, fallback: string): string {
  return typeof v === 'string' && v.length > 0 ? v : fallback
}
function strOpt(v: YamlValue | undefined): string | undefined {
  return typeof v === 'string' && v.length > 0 ? v : undefined
}
function num(v: YamlValue | undefined, fallback: number): number {
  return typeof v === 'number' && Number.isFinite(v) ? v : fallback
}
function bool(v: YamlValue | undefined, fallback: boolean): boolean {
  return typeof v === 'boolean' ? v : fallback
}
function strList(v: YamlValue | undefined, fallback: string[]): string[] {
  return Array.isArray(v) ? v.map(String) : fallback
}

/** 读取 config/agent.yml（可用 DSH_AGENT_CONFIG 覆盖路径）。 */
export function loadAgentConfig(): AgentConfig {
  const path = process.env.DSH_AGENT_CONFIG ?? join(process.cwd(), 'config', 'agent.yml')
  const doc = parseYamlFile(path) ?? {}
  const llm = (doc.llm ?? {}) as { [k: string]: YamlValue }
  const tools = (doc.tools ?? {}) as { [k: string]: YamlValue }
  const planning = (doc.planning ?? {}) as { [k: string]: YamlValue }
  const reflection = (doc.reflection ?? {}) as { [k: string]: YamlValue }
  const memory = (doc.memory ?? {}) as { [k: string]: YamlValue }
  const context = (doc.context ?? {}) as { [k: string]: YamlValue }
  const persistence = (doc.persistence ?? {}) as { [k: string]: YamlValue }
  const server = (doc.server ?? {}) as { [k: string]: YamlValue }
  return {
    persona: str(doc.persona, DEFAULTS.persona),
    llm: {
      provider: str(llm.provider, DEFAULTS.llm.provider),
      model: str(llm.model, DEFAULTS.llm.model),
      baseURL: str(llm.baseURL, DEFAULTS.llm.baseURL),
      apiKeyEnv: str(llm.apiKeyEnv, DEFAULTS.llm.apiKeyEnv),
      maxTokens: num(llm.maxTokens, DEFAULTS.llm.maxTokens),
      timeoutMs: num(llm.timeoutMs, DEFAULTS.llm.timeoutMs),
      temperature: num(llm.temperature, DEFAULTS.llm.temperature),
    },
    tools: {
      enabled: strList(tools.enabled, DEFAULTS.tools.enabled),
      requireApproval: strList(tools.requireApproval, DEFAULTS.tools.requireApproval),
      workspaceRoot: str(tools.workspaceRoot, DEFAULTS.tools.workspaceRoot),
    },
    planning: {
      enabled: bool(planning.enabled, DEFAULTS.planning.enabled),
      maxSteps: num(planning.maxSteps, DEFAULTS.planning.maxSteps),
      maxReplans: num(planning.maxReplans, DEFAULTS.planning.maxReplans),
    },
    reflection: { enabled: bool(reflection.enabled, DEFAULTS.reflection.enabled), maxCorrections: num(reflection.maxCorrections, DEFAULTS.reflection.maxCorrections) },
    memory: {
      enabled: bool(memory.enabled, DEFAULTS.memory.enabled),
      inject: bool(memory.inject, DEFAULTS.memory.inject),
      maxInjectedItems: num(memory.maxInjectedItems, DEFAULTS.memory.maxInjectedItems),
      shortTermTurns: num(memory.shortTermTurns, DEFAULTS.memory.shortTermTurns),
      maxNoteBytes: num(memory.maxNoteBytes, DEFAULTS.memory.maxNoteBytes),
    },
    context: {
      tokenBudget: num(context.tokenBudget, DEFAULTS.context.tokenBudget),
      summarizeThreshold: num(context.summarizeThreshold, DEFAULTS.context.summarizeThreshold),
      maxSummarizeRetries: num(context.maxSummarizeRetries, DEFAULTS.context.maxSummarizeRetries),
    },
    persistence: { dir: str(persistence.dir, DEFAULTS.persistence.dir) },
    server: { host: str(server.host, DEFAULTS.server.host), port: num(server.port, DEFAULTS.server.port) },
  }
}

/** $DSH_HOME：环境变量 > ~/.dsh。 */
export function dshHome(): string {
  const env = process.env.DSH_HOME
  return env && env.length > 0 ? env : join(homedir(), '.dsh')
}

/** $DSH_HOME/settings.yaml 的默认供应商（agent-default-model + llm-pi-ai.providers）。 */
export function loadDshSettings(): { provider?: string; model?: string; baseURL?: string; apiKeyEnv?: string } {
  const doc = parseYamlFile(join(dshHome(), 'settings.yaml'))
  if (!doc) return {}
  const adm = (doc['agent-default-model'] ?? {}) as { [k: string]: YamlValue }
  const pi = (doc['llm-pi-ai'] ?? {}) as { [k: string]: YamlValue }
  const providers = (pi.providers ?? {}) as { [k: string]: YamlValue }
  const providerName = strOpt(adm.provider)
  if (!providerName) return { provider: strOpt(adm.provider) }
  const profile = (providers[providerName] ?? {}) as { [k: string]: YamlValue }
  const models = Array.isArray(profile.models) ? profile.models : []
  const firstModel = models.length > 0 ? (models[0] as { [k: string]: YamlValue }) : undefined
  return {
    provider: providerName,
    model: strOpt(adm.model) ?? (firstModel ? strOpt(firstModel.id) : undefined),
    baseURL: strOpt(profile.baseURL),
    apiKeyEnv: strOpt(profile.apiKeyEnv),
  }
}

/** $DSH_HOME/.credentials.yaml 的 refs（名字 → 值）。 */
export function loadDshCredentials(): Map<string, string> {
  const doc = parseYamlFile(join(dshHome(), '.credentials.yaml'))
  const refs = new Map<string, string>()
  if (!doc) return refs
  const section = (doc.refs ?? {}) as { [k: string]: YamlValue }
  for (const [name, value] of Object.entries(section)) {
    if (typeof value === 'string' && value.length > 0) refs.set(name, value)
  }
  return refs
}

/** 解析最终 LLM 配置。 */
export function resolveLlmConfig(cfg: AgentConfig, mock = false): LlmConfig {
  if (mock || cfg.llm.provider === 'mock' || process.env.DSH_LLM_PROVIDER === 'mock') {
    return { provider: 'mock', baseURL: '', apiKey: undefined, model: 'mock-model', maxTokens: cfg.llm.maxTokens, timeoutMs: cfg.llm.timeoutMs, temperature: cfg.llm.temperature }
  }
  const settings = loadDshSettings()
  const credentials = loadDshCredentials()
  const provider = process.env.DSH_LLM_PROVIDER ?? settings.provider ?? (cfg.llm.provider !== 'auto' ? cfg.llm.provider : undefined) ?? 'openai-completions'
  const apiKeyEnv = process.env.DSH_LLM_API_KEY_ENV ?? settings.apiKeyEnv ?? (cfg.llm.apiKeyEnv !== 'auto' ? cfg.llm.apiKeyEnv : undefined) ?? 'DEEPSEEK_API_KEY'
  const baseURL = process.env.DSH_LLM_BASE_URL ?? settings.baseURL ?? (cfg.llm.baseURL !== 'auto' ? cfg.llm.baseURL : undefined) ?? 'https://api.deepseek.com/v1'
  const model = process.env.DSH_LLM_MODEL ?? settings.model ?? (cfg.llm.model !== 'auto' ? cfg.llm.model : undefined) ?? 'deepseek-chat'
  const apiKey = process.env.DSH_LLM_API_KEY ?? process.env[apiKeyEnv] ?? credentials.get(apiKeyEnv) ?? undefined
  return { provider, baseURL: baseURL.replace(/\/+$/, ''), apiKey, model, maxTokens: cfg.llm.maxTokens, timeoutMs: cfg.llm.timeoutMs, temperature: cfg.llm.temperature }
}

export function resolveDataDir(cfg: AgentConfig): string {
  return resolve(process.cwd(), cfg.persistence.dir)
}

export function resolveWorkspaceRoot(cfg: AgentConfig): string {
  return resolve(process.cwd(), cfg.tools.workspaceRoot)
}
