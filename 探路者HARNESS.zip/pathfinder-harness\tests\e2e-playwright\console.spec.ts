/**
 * console.spec.ts —— 苹果风格控制台端到端测试（Playwright）。
 *
 * 覆盖用户要求的：
 *   1. 控制台基本交互：发送消息、流式接收回复
 *   2. 查看记忆面板（长期记忆/偏好）
 *   3. 记忆编辑功能（添加/删除）
 *   4. 响应式布局（桌面端侧边栏固定 / 移动端抽屉式）
 *
 * 注意：本测试需真实浏览器，请在无受限沙箱环境运行（npm run test:e2e）。
 */

import { test, expect } from 'playwright/test'

test.describe('控制台基本交互', () => {
  test('发送消息并流式接收回复', async ({ page }) => {
    await page.goto('/')
    await expect(page.getByText('你好，我是探路者HARNESS')).toBeVisible()

    await page.getByPlaceholder('给 Agent 发送消息…').fill('帮我算一下 1+2')
    await page.getByRole('button', { name: '发送' }).click()

    // 用户消息气泡（靠右）
    await expect(page.locator('.msg.user').first()).toContainText('帮我算一下 1+2')
    // Agent 回复气泡出现（含流式结果）
    await expect(page.locator('.msg.agent').first()).toBeVisible({ timeout: 30_000 })
    await expect(page.locator('.msg.agent').first()).toContainText(/1\+2 = 3|计算/, { timeout: 30_000 })
  })

  test('工具调用展示为卡片', async ({ page }) => {
    await page.goto('/')
    await page.getByPlaceholder('给 Agent 发送消息…').fill('查一下北京天气')
    await page.getByRole('button', { name: '发送' }).click()
    await expect(page.locator('.tool-card').first()).toBeVisible({ timeout: 30_000 })
    await expect(page.locator('.tool-card').first()).toContainText(/weather|天气/, { timeout: 30_000 })
  })

  test('反馈按钮可点击', async ({ page }) => {
    await page.goto('/')
    await page.getByPlaceholder('给 Agent 发送消息…').fill('你好')
    await page.getByRole('button', { name: '发送' }).click()
    await expect(page.locator('.msg.agent').first()).toBeVisible({ timeout: 30_000 })
    await page.locator('.msg.agent').first().hover()
    await page.locator('.msg.agent .feedback-btn.up').first().click()
    await expect(page.locator('.toast')).toContainText(/反馈|偏好/, { timeout: 10_000 })
  })
})

test.describe('记忆面板', () => {
  test('查看并编辑记忆（单篇提示词）', async ({ page }) => {
    await page.goto('/')
    // 切到记忆标签
    await page.getByRole('button', { name: '记忆' }).click()
    await expect(page.getByText('记忆（提示词）')).toBeVisible()

    // 编辑单篇记忆文本并保存
    const textarea = page.locator('#memoryText')
    await textarea.fill('- [事实] 用户住在北京')
    await page.getByRole('button', { name: '保存记忆' }).click()
    await expect(page.locator('#memoryText')).toHaveValue(/- \[事实\] 用户住在北京/)
  })

  test('清空记忆', async ({ page }) => {
    await page.goto('/')
    await page.getByRole('button', { name: '记忆' }).click()
    const textarea = page.locator('#memoryText')
    await textarea.fill('- [事实] 待清空')
    await page.getByRole('button', { name: '保存记忆' }).click()
    page.on('dialog', (dialog) => dialog.accept())
    await page.getByRole('button', { name: '清空' }).click()
    await expect(page.locator('#memoryText')).toHaveValue('')
  })
})

test.describe('响应式布局', () => {
  test('桌面端：侧边栏可见', async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== 'desktop', '仅桌面项目')
    await page.goto('/')
    await expect(page.locator('.sidebar')).toBeVisible()
    await expect(page.locator('#hamburger')).toBeHidden()
  })

  test('移动端：侧边栏为抽屉，汉堡菜单可展开', async ({ page }, testInfo) => {
    test.skip(testInfo.project.name !== 'mobile', '仅移动项目')
    await page.goto('/')
    // 初始侧边栏收起
    await expect(page.locator('.sidebar')).not.toHaveClass(/open/)
    await expect(page.locator('#hamburger')).toBeVisible()
    await page.locator('#hamburger').click()
    await expect(page.locator('.sidebar')).toHaveClass(/open/)
  })
})
