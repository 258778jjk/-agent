/**
 * main —— CLI 入口（对应 DSH: apps/cli + dsh-headless）。
 *
 * 子命令：
 *   ask      "任务" [--resume <id>] [--mock] [--yes]     单轮/多轮对话（终端）
 *   serve    [--port N] [--mock]                          启动 Web 控制台
 *   memory   [--all]                                      查看长期记忆与偏好
 *   feedback <sid> <mid> up|down|delete [--note]          记录反馈
 *   sessions                                              列出会话
 */

import { createInterface } from 'node:readline/promises'
import { SessionStore, textOf } from './session.ts'
import { createTools } from './tools.ts'
import { MemoryStore } from './memory.ts'
import { runTurn, type AgentHooks } from './agent.ts'
import { loadAgentConfig, resolveDataDir, resolveWorkspaceRoot } from './config.ts'
import { MockLlm, demoMockScript } from './llm.ts'
import { RuntimeStore } from './runtime.ts'
import { startServer } from './server.ts'

interface Args {
  cmd: string
  positional: string[]
  flags: Record<string, string | boolean>
}

function parseArgs(argv: string[]): Args {
  const cmd = argv[0] ?? 'help'
  const positional: string[] = []
  const flags: Record<string, string | boolean> = {}
  // 需要值的标志（其它 --flag 一律视为布尔）
  const valueFlags = new Set(['resume', 'port', 'note', 'config'])
  for (let i = 1; i < argv.length; i++) {
    const arg = argv[i]!
    if (arg.startsWith('--')) {
      const name = arg.slice(2)
      const eq = name.indexOf('=')
      if (eq >= 0) {
        flags[name.slice(0, eq)] = name.slice(eq + 1)
      } else if (valueFlags.has(name) && i + 1 < argv.length) {
        flags[name] = argv[++i]!
      } else {
        flags[name] = true
      }
    } else {
      positional.push(arg)
    }
  }
  return { cmd, positional, flags }
}

const HELP = `探路者HARNESS — 智能 Agent 系统

用法:
  node src/main.ts ask "任务" [--resume <sessionId>] [--mock] [--yes]
  node src/main.ts serve [--port <N>] [--mock]
  node src/main.ts memory [--all]
  node src/main.ts feedback <sessionId> <messageId> up|down|delete [--note "评语"]
  node src/main.ts sessions

说明:
  --mock   使用内置模拟模型（无 key 演示 / 测试）
  --yes    自动批准所有需要确认的工具（file_write 等）
  --resume 继续已有会话（保留上下文 + 记忆）
`;

function printEvent(ev: { type: string; step?: number; detail?: unknown }): void {
  const pad = ev.step != null ? `step/${ev.step}` : '──'
  switch (ev.type) {
    case 'turn/start':
      process.stderr.write('\n── turn/start\n')
      break
    case 'plan/created': {
      const plan = ev.detail as { steps: Array<{ id: number; title: string; tool?: string | null; priority: number }> } | undefined
      process.stderr.write('  📋 计划：\n')
      for (const s of plan?.steps ?? []) process.stderr.write(`     ${s.id}. ${s.title}${s.tool ? ` (${s.tool})` : ''} [p${s.priority}]\n`)
      break
    }
    case 'step/start':
      process.stderr.write(`  └─ ${pad} 开始\n`)
      break
    case 'assistant/message':
      break
    case 'tool/result': {
      const d = ev.detail as { name?: string; ok?: boolean; denied?: boolean; output?: string }
      const mark = d.denied ? '🚫' : d.ok ? '✓' : '✗'
      process.stderr.write(`     ${mark} ${d.name ?? ''}: ${(d.output ?? '').slice(0, 120)}\n`)
      break
    }
    case 'reflection': {
      const d = ev.detail as { action?: string; ok?: boolean; reason?: string } | { length?: number }
      if (d && 'action' in d && d.action) process.stderr.write(`     💭 反思: ${d.action} → ${d.ok ? '有效' : '无效'}（${d.reason}）\n`)
      break
    }
    case 'correction':
      process.stderr.write(`     🔁 修正: ${String(ev.detail)}\n`)
      break
    case 'context/summarized':
      process.stderr.write(`  🧠 ${String(ev.detail)}\n`)
      break
    case 'error':
      process.stderr.write(`  ⚠ ${String(ev.detail)}\n`)
      break
    case 'interrupted':
      process.stderr.write('\n  ⏹ 已中断\n')
      break
    case 'step/end':
    case 'turn/end':
      break
  }
}

/** 终端审批：交互环境读 y/n，--yes 自动批准，非 TTY 自动拒绝。 */
function makeApproval(autoApprove: boolean): AgentHooks['askApproval'] {
  if (autoApprove) return async () => true
  const rl = process.stdin.isTTY ? createInterface({ input: process.stdin, output: process.stderr }) : undefined
  return async (name, args) => {
    if (!rl) {
      process.stderr.write(`  🚫 非交互环境，自动拒绝工具 ${name}（可用 --yes 批准）\n`)
      return false
    }
    const answer = await rl.question(`\n  ⚠ 工具 ${name}(${JSON.stringify(args).slice(0, 200)}) 需要确认 [y/N]: `)
    return answer.trim().toLowerCase() === 'y'
  }
}

async function cmdAsk(positional: string[], flags: Record<string, string | boolean>): Promise<number> {
  const task = positional[0]
  if (!task) {
    process.stderr.write('用法: node src/main.ts ask "任务"\n')
    return 2
  }
  const mock = flags.mock === true
  const autoApprove = flags.yes === true
  const config = loadAgentConfig()
  const dataDir = resolveDataDir(config)
  const runtime = new RuntimeStore(dataDir)
  const llm = runtime.resolveLlm(config, mock)
  const store = new SessionStore(dataDir)
  const memory = new MemoryStore(dataDir, { maxNoteBytes: config.memory.maxNoteBytes })
  const tools = createTools(config.tools.enabled, config.tools.requireApproval)
  const workspaceRoot = runtime.resolveWorkspace(resolveWorkspaceRoot(config))

  const resumeId = typeof flags.resume === 'string' ? flags.resume : undefined
  let session = resumeId ? store.load(resumeId) : undefined
  if (resumeId && !session) {
    process.stderr.write(`会话不存在: ${resumeId}\n`)
    return 1
  }
  if (!session) session = store.create(process.cwd())
  const persist = () => store.save(session!)
  const sessionId = session.header.id

  process.stderr.write(`[探路者HARNESS] session=${sessionId} llm=${llm.provider}/${llm.model} tools=${config.tools.enabled.join(',')}\n`)

  // 用户消息先落盘（铁律：模型可见 ⟺ 已落盘）
  session.append('user', [{ type: 'text', text: task }], { kind: 'user' })
  persist()

  const hooks: AgentHooks = {
    onEvent: printEvent,
    onDelta: (text) => process.stdout.write(text),
    askApproval: makeApproval(autoApprove),
  }
  const mockLlm = mock ? new MockLlm(demoMockScript()) : undefined

  const result = await runTurn({ session, config, llm, tools, memory, hooks, persist, workspaceRoot, mockLlm })
  process.stdout.write('\n')
  process.stderr.write(`\n[v0] usage=${result.usage ? `${result.usage.inputTokens}in/${result.usage.outputTokens}out` : 'n/a'} steps=${result.steps}${result.interrupted ? ' interrupted' : ''}\n`)
  const last = session.assistantMessages().at(-1)
  if (last) process.stderr.write(`[v0] 对该回复给反馈 → node src/main.ts feedback ${sessionId} ${last.id} up --note "很好"\n`)
  return 0
}

async function cmdServe(flags: Record<string, string | boolean>): Promise<number> {
  const mock = flags.mock === true
  const config = loadAgentConfig()
  const port = typeof flags.port === 'string' ? Number.parseInt(flags.port, 10) : config.server.port
  await startServer(config, { port, mock })
  return 0
}

async function cmdMemory(flags: Record<string, string | boolean>): Promise<number> {
  const config = loadAgentConfig()
  const memory = new MemoryStore(resolveDataDir(config), { maxNoteBytes: config.memory.maxNoteBytes })
  const prompt = memory.getPrompt()
  process.stdout.write(`=== 长期记忆（单篇提示词） ===\n`)
  process.stdout.write(prompt.trim() !== '' ? prompt + '\n' : '（空）\n')
  if (flags.all) {
    process.stdout.write(`\n=== 反馈汇总 ===\n`)
    const all = memory.listAllFeedback()
    for (const [sid, items] of all) {
      for (const it of items) process.stdout.write(`  ${sid} ${it.messageId} ${it.rating === 'positive' ? '👍' : '👎'}${it.note ? ` "${it.note}"` : ''}\n`)
    }
  }
  return 0
}

async function cmdFeedback(positional: string[], flags: Record<string, string | boolean>): Promise<number> {
  const [sid, mid, action] = positional
  if (!sid || !mid || !action) {
    process.stderr.write('用法: node src/main.ts feedback <sessionId> <messageId> up|down|delete [--note "评语"]\n')
    return 2
  }
  const config = loadAgentConfig()
  const store = new SessionStore(resolveDataDir(config))
  const memory = new MemoryStore(resolveDataDir(config), { maxNoteBytes: config.memory.maxNoteBytes })
  const session = store.load(sid)
  if (!session) {
    process.stderr.write(`会话不存在: ${sid}\n`)
    return 1
  }
  if (action === 'delete') {
    const existing = memory.getFeedback(sid, mid)
    if (!existing) {
      process.stderr.write('该消息无反馈\n')
      return 0
    }
    const res = memory.putFeedback(sid, { messageId: mid, rating: existing.rating, ifVersion: existing.version, note: '' })
    process.stdout.write(res.ok ? '已删除\n' : `失败: ${res.message}\n`)
    return res.ok ? 0 : 1
  }
  const target = session.find(mid)
  if (!target || target.role !== 'assistant') {
    process.stderr.write(`目标消息不存在或不是助手消息: ${mid}\n`)
    return 1
  }
  const rating = action === 'up' ? 'positive' : 'negative'
  const existing = memory.getFeedback(sid, mid)
  const note = typeof flags.note === 'string' ? flags.note : undefined
  const res = memory.putFeedback(sid, { messageId: mid, rating, note, ifVersion: existing?.version ?? null })
  if (!res.ok) {
    process.stderr.write(`失败: ${res.message}\n`)
    return 1
  }
  // 反馈驱动偏好提取
  if (note && note.trim() !== '') {
    const { extractPreferenceFromNote } = await import('./memory.ts')
    const pref = extractPreferenceFromNote(note, rating)
    if (pref) {
      memory.addMemory('preference', pref, sid, 'feedback')
      process.stdout.write(`  已提取偏好: ${pref}\n`)
    }
  }
  process.stdout.write(`已记录: ${mid} → ${rating === 'positive' ? 'positive 👍' : 'negative 👎'}${note ? ` note="${note}"` : ''}\n`)
  return 0
}

async function cmdSessions(): Promise<number> {
  const config = loadAgentConfig()
  const store = new SessionStore(resolveDataDir(config))
  const ids = store.list()
  if (ids.length === 0) {
    process.stdout.write('（无会话）\n')
    return 0
  }
  for (const id of ids) {
    const session = store.load(id)
    if (!session) continue
    const last = [...session.messages].reverse().find((m) => m.role === 'assistant' || m.role === 'user')
    process.stdout.write(`${id}  messages=${session.messages.length}  last="${last ? textOf(last).slice(0, 40) : ''}"\n`)
  }
  return 0
}

async function main(): Promise<number> {
  const { cmd, positional, flags } = parseArgs(process.argv.slice(2))
  switch (cmd) {
    case 'ask':
      return cmdAsk(positional, flags)
    case 'serve':
      return cmdServe(flags)
    case 'memory':
      return cmdMemory(flags)
    case 'feedback':
      return cmdFeedback(positional, flags)
    case 'sessions':
      return cmdSessions()
    default:
      process.stdout.write(HELP)
      return 0
  }
}

main()
  .then((code) => {
    process.exitCode = code
  })
  .catch((error) => {
    process.stderr.write(`[fatal] ${error instanceof Error ? error.stack ?? error.message : String(error)}\n`)
    process.exitCode = 1
  })
