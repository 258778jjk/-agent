/**
 * planner.test.ts —— 规划模块单元测试
 * 覆盖：计划 JSON 解析、优先级排序、状态推进、失败重规划、解析失败降级。
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { Planner, parsePlan } from '../src/planner.ts'

const TOOLS = ['calculator', 'weather', 'file_write']

function makePlanner(gen: (p: string) => Promise<string>) {
  return new Planner({ enabled: true, maxSteps: 10, maxReplans: 2 }, TOOLS, { generatePlan: gen })
}

const PLAN_JSON = JSON.stringify({
  steps: [
    { id: 1, title: '查询天气', tool: 'weather', priority: 3, status: 'pending' },
    { id: 2, title: '计算结果', tool: 'calculator', priority: 1, status: 'pending' },
    { id: 3, title: '汇总', tool: null, priority: 2, status: 'pending' },
  ],
})

test('parsePlan：解析纯 JSON', () => {
  const plan = parsePlan(PLAN_JSON)
  assert.ok(plan)
  assert.equal(plan!.steps.length, 3)
})

test('parsePlan：容忍 markdown 代码围栏', () => {
  const plan = parsePlan('```json\n' + PLAN_JSON + '\n```')
  assert.ok(plan)
  assert.equal(plan!.steps.length, 3)
})

test('parsePlan：非法输入返回 undefined', () => {
  assert.equal(parsePlan('没有计划'), undefined)
  assert.equal(parsePlan(''), undefined)
})

test('ensurePlan：复杂请求被拆解为子任务序列', async () => {
  const planner = makePlanner(async () => PLAN_JSON)
  const plan = await planner.ensurePlan('先算数再查天气最后汇总')
  assert.equal(plan.steps.length, 3)
})

test('nextStep：按优先级取出步骤', async () => {
  const planner = makePlanner(async () => PLAN_JSON)
  await planner.ensurePlan('任务')
  const first = planner.nextStep()
  assert.equal(first!.title, '计算结果') // priority 1
})

test('状态推进：done/skip 后 isFinished 判定', async () => {
  const planner = makePlanner(async () => PLAN_JSON)
  await planner.ensurePlan('任务')
  const s1 = planner.nextStep()!
  planner.markDone(s1.id)
  const s2 = planner.nextStep()!
  planner.markDone(s2.id)
  const s3 = planner.nextStep()!
  planner.markSkipped(s3.id)
  assert.equal(planner.isFinished(), true)
})

test('失败重规划：生成新步骤替换 pending', async () => {
  let call = 0
  const planner = makePlanner(async () => {
    call++
    if (call === 1) return PLAN_JSON
    return JSON.stringify({ steps: [{ id: 9, title: '补救步骤', tool: 'calculator', priority: 1, status: 'pending' }] })
  })
  await planner.ensurePlan('任务')
  const failed = planner.nextStep()!
  planner.markFailed(failed.id)
  const replanned = await planner.replan(failed, '工具异常')
  assert.equal(replanned, true)
  assert.ok(planner.current!.steps.some((s) => s.title === '补救步骤'))
})

test('重规划次数上限：超过 maxReplans 拒绝', async () => {
  const planner = new Planner({ enabled: true, maxSteps: 10, maxReplans: 1 }, TOOLS, {
    generatePlan: async () => JSON.stringify({ steps: [{ id: 1, title: 'x', tool: null, priority: 1, status: 'pending' }] }),
  })
  await planner.ensurePlan('任务')
  const s = planner.nextStep()!
  planner.markFailed(s.id)
  const ok1 = await planner.replan(s, 'err')
  const s2 = planner.nextStep()!
  planner.markFailed(s2.id)
  const ok2 = await planner.replan(s2, 'err')
  assert.equal(ok1, true)
  assert.equal(ok2, false)
})

test('解析失败：优雅降级为单步计划', async () => {
  const planner = makePlanner(async () => '不是 JSON')
  const plan = await planner.ensurePlan('随便做点什么')
  assert.equal(plan.steps.length, 1)
  assert.equal(plan.steps[0]!.title, '执行用户请求')
})
