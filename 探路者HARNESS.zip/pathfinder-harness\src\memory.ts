/**
 * memory —— 反馈记忆系统（对应 DSH: dsh-message-feedback 数据模型 + 记忆注入层）。
 *
 * 记忆存储模型（v0.3 起改为「单篇浓缩提示词」）：
 *   - 长期记忆 = 一篇可复制、可直接编辑的纯文本（data/memory/prompt.txt）
 *   - 每条记忆占一行，格式：- [事实] ... / - [用户偏好] ... / - [教训] ...
 *   - 反馈（up/down+note）、用户「记住…」指令、反思教训 都追加为新行
 *   - buildMemoryBlock() 直接把整篇文本包裹为 <memory> 注入 system prompt
 *   - 前端以单个 textarea 展示，可复制/编辑/保存/清空
 *
 * 短期记忆：当前会话消息历史（session）+ 本会话反思日志（内存）。
 * 反馈 sidecar：data/feedback/<sessionId>.json（CAS 版本控制）。
 */

import { randomUUID } from 'node:crypto'
import { mkdirSync, readFileSync, writeFileSync, existsSync, readdirSync, appendFileSync } from 'node:fs'
import { join } from 'node:path'

export type MemoryKind = 'fact' | 'preference' | 'reflection'

export type FeedbackRating = 'positive' | 'negative'

export interface FeedbackItem {
  messageId: string
  rating: FeedbackRating
  note?: string
  version: string
  createdAt: number
  updatedAt: number
}

export interface ReflectionEntry {
  id: string
  sessionId: string
  turn: number
  step: number
  action: string
  ok: boolean
  reason: string
  adjustment: string
  createdAt: number
}

export interface MemoryStoreOptions {
  maxNoteBytes: number
}

const KIND_LABEL: Record<MemoryKind, string> = {
  fact: '事实',
  preference: '用户偏好',
  reflection: '教训',
}

/** 从反馈评语提取偏好（规则 + 关键词）。 */
export function extractPreferenceFromNote(note: string, rating: FeedbackRating): string | undefined {
  const text = note.trim()
  if (text === '') return undefined
  const keywords = ['记住', '以后', '请', '希望', '偏好', '不要', '别', '更', '尽量', '总是']
  const hasIntent = keywords.some((k) => text.includes(k))
  if (rating === 'negative') return `用户不满意并要求：${text}`
  if (rating === 'positive' && hasIntent) return `用户满意并希望保持：${text}`
  if (rating === 'positive') return `用户满意：${text}`
  return undefined
}

/** 从用户消息提取显式记忆指令（"记住…"）。 */
export function extractFactsFromMessage(text: string): string[] {
  const facts: string[] = []
  const re = /(?:请)?记住[：:，,]?\s*([^。！？!?\n]{2,100})/g
  let m: RegExpExecArray | null
  while ((m = re.exec(text)) !== null) {
    facts.push(m[1]!.trim())
  }
  return facts
}

export class MemoryStore {
  private readonly promptFile: string
  private readonly feedbackDir: string
  private readonly opts: MemoryStoreOptions

  constructor(root: string, opts: MemoryStoreOptions) {
    this.opts = opts
    this.promptFile = join(root, 'memory', 'prompt.txt')
    this.feedbackDir = join(root, 'feedback')
    mkdirSync(join(root, 'memory'), { recursive: true })
    mkdirSync(this.feedbackDir, { recursive: true })
    if (!existsSync(this.promptFile)) writeFileSync(this.promptFile, '', 'utf8')
  }

  /* ---------- 长期记忆（单篇文本） ---------- */

  /** 读取整篇记忆文本。 */
  getPrompt(): string {
    try {
      return readFileSync(this.promptFile, 'utf8').replace(/\s+$/, '')
    } catch {
      return ''
    }
  }

  /** 覆盖整篇记忆文本（用户在前端编辑保存）。 */
  setPrompt(text: string): void {
    writeFileSync(this.promptFile, text.replace(/\s+$/, '') + (text.trim() !== '' ? '\n' : ''), 'utf8')
  }

  /** 追加一条记忆（一行）。自动去重（完全相同的内容不重复写）。 */
  addMemory(kind: MemoryKind, text: string, _sessionId?: string, _source = 'user-explicit'): { kind: MemoryKind; text: string } {
    const line = `- [${KIND_LABEL[kind]}] ${text.trim()}`
    const current = this.getPrompt()
    if (current.split(/\r?\n/).some((l) => l.trim() === line.trim())) return { kind, text: text.trim() }
    appendFileSync(this.promptFile, line + '\n', 'utf8')
    return { kind, text: text.trim() }
  }

  /** 清空记忆。 */
  clear(): void {
    writeFileSync(this.promptFile, '', 'utf8')
  }

  /** 渲染注入给模型的记忆块（整篇文本，非空时包裹 <memory>）。 */
  buildMemoryBlock(_maxItems?: number): string {
    const prompt = this.getPrompt()
    if (prompt.trim() === '') return ''
    return `<memory>\n以下是长期积累的用户事实、偏好与经验教训，请在行为中严格遵守：\n${prompt}\n</memory>`
  }

  /* ---------- 反馈 sidecar（CAS） ---------- */

  private feedbackFile(sessionId: string): string {
    return join(this.feedbackDir, `${sessionId}.json`)
  }

  listFeedback(sessionId: string): FeedbackItem[] {
    const file = this.feedbackFile(sessionId)
    if (!existsSync(file)) return []
    try {
      const doc = JSON.parse(readFileSync(file, 'utf8')) as { items?: FeedbackItem[] }
      return doc.items ?? []
    } catch {
      return []
    }
  }

  getFeedback(sessionId: string, messageId: string): FeedbackItem | undefined {
    return this.listFeedback(sessionId).find((i) => i.messageId === messageId)
  }

  putFeedback(
    sessionId: string,
    request: { messageId: string; rating: FeedbackRating; note?: string; ifVersion: string | null },
  ): { ok: true; item: FeedbackItem } | { ok: false; code: string; message: string } {
    const now = Date.now()
    const note = request.note?.trim()
    if (note !== undefined && note.length === 0) return { ok: false, code: 'note-blank', message: '评语不能为空' }
    if (note !== undefined && Buffer.byteLength(note, 'utf8') > this.opts.maxNoteBytes) {
      return { ok: false, code: 'note-too-large', message: `评语超过 ${this.opts.maxNoteBytes} 字节` }
    }
    const items = this.listFeedback(sessionId)
    const existing = items.find((i) => i.messageId === request.messageId)
    if (existing && existing.version !== request.ifVersion) return { ok: false, code: 'version-conflict', message: '版本冲突，请刷新后重试' }
    if (!existing && request.ifVersion !== null) return { ok: false, code: 'version-conflict', message: '条目不存在，ifVersion 必须为 null' }
    const item: FeedbackItem = existing
      ? { ...existing, rating: request.rating, ...(note !== undefined ? { note } : {}), version: randomUUID(), updatedAt: now }
      : { messageId: request.messageId, rating: request.rating, ...(note !== undefined ? { note } : {}), version: randomUUID(), createdAt: now, updatedAt: now }
    const next = existing ? items.map((i) => (i.messageId === request.messageId ? item : i)) : [...items, item]
    writeFileSync(this.feedbackFile(sessionId), JSON.stringify({ items: next }, null, 2), 'utf8')
    return { ok: true, item }
  }

  listAllFeedback(): Map<string, FeedbackItem[]> {
    const result = new Map<string, FeedbackItem[]>()
    if (!existsSync(this.feedbackDir)) return result
    for (const file of readdirSync(this.feedbackDir)) {
      if (!file.endsWith('.json')) continue
      result.set(file.slice(0, -'.json'.length), this.listFeedback(file.slice(0, -'.json'.length)))
    }
    return result
  }

  /* ---------- 反思日志（短期，会话内） ---------- */

  private reflections = new Map<string, ReflectionEntry[]>()

  listReflections(sessionId: string): ReflectionEntry[] {
    return this.reflections.get(sessionId) ?? []
  }

  addReflection(entry: Omit<ReflectionEntry, 'id' | 'createdAt'>): ReflectionEntry {
    const full: ReflectionEntry = { ...entry, id: randomUUID(), createdAt: Date.now() }
    const list = this.reflections.get(entry.sessionId) ?? []
    list.push(full)
    this.reflections.set(entry.sessionId, list.slice(-200))
    return full
  }

  /** 反思中值得长期保留的教训（失败 + 有调整方向）。 */
  promoteReflection(sessionId: string): void {
    const recent = this.listReflections(sessionId).slice(-3)
    for (const r of recent) {
      if (!r.ok && r.adjustment.trim() !== '' && r.reason !== '') {
        const text = `在${r.action}时曾失败（${r.reason}），调整方式：${r.adjustment}`
        if (!this.getPrompt().includes(text)) this.addMemory('reflection', text, sessionId, 'reflection')
      }
    }
  }
}
