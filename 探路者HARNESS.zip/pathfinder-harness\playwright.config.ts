/**
 * playwright.config.ts —— 前端端到端测试配置。
 *
 * 运行方式（需可下载浏览器的环境，非受限沙箱）：
 *   npm run test:e2e
 *
 * webServer 自动以 mock 模式启动控制台，跑完自动关闭。
 */

import { defineConfig } from 'playwright/test'

export default defineConfig({
  testDir: './tests/e2e-playwright',
  timeout: 60_000,
  retries: 0,
  reporter: [['list']],
  use: {
    baseURL: 'http://127.0.0.1:3088',
    headless: true,
    viewport: { width: 1280, height: 800 },
  },
  projects: [
    { name: 'desktop', use: { viewport: { width: 1280, height: 800 } } },
    { name: 'mobile', use: { viewport: { width: 390, height: 844 } } },
  ],
  webServer: {
    command: 'node src/main.ts serve --mock --port 3088',
    url: 'http://127.0.0.1:3088',
    reuseExistingServer: true,
    timeout: 30_000,
  },
})
