/**
 * runtime —— 运行时供应商注册表 + 运行设置（工作区 / 默认供应商 / 模型 / 温度 / Token）。
 *
 * 对标 DSH 的 llm-pi-ai 供应商配置 + credentials：
 *   - 用户可在 Web 控制台「设置」里自定义提供方（Provider ID / 显示名称 / API 地址 / 协议 / API 密钥 / 模型目录）
 *   - 选定默认供应商与模型后，对话即按该配置发起请求
 *   - 工作区是文件工具（file_read/file_write）的根目录
 *
 * 持久化：
 *   data/providers.json  —— 供应商列表（含 apiKey，注意：data/ 已 gitignore）
 *   data/settings.json   —— 运行设置
 */

import { mkdirSync, readFileSync, writeFileSync, existsSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { resolveLlmConfig, type AgentConfig, type LlmConfig } from './config.ts'

export interface ProviderDef {
  id: string
  displayName: string
  baseURL: string
  protocol: string // 'openai-completions'
  apiKey: string
  /** 模型目录 */
  models: string[]
  /** 该供应商默认模型 */
  model: string
  createdAt: number
}

export interface RuntimeSettings {
  workspace: string
  providerId: string
  model: string
  temperature: number
  maxTokens: number
}

const DEFAULT_SETTINGS: RuntimeSettings = {
  workspace: '',
  providerId: '',
  model: '',
  temperature: 0.3,
  maxTokens: 4096,
}

export class RuntimeStore {
  private readonly providersFile: string
  private readonly settingsFile: string

  constructor(root: string) {
    mkdirSync(root, { recursive: true })
    this.providersFile = join(root, 'providers.json')
    this.settingsFile = join(root, 'settings.json')
    if (!existsSync(this.providersFile)) writeFileSync(this.providersFile, '[]', 'utf8')
    if (!existsSync(this.settingsFile)) writeFileSync(this.settingsFile, JSON.stringify(DEFAULT_SETTINGS, null, 2), 'utf8')
  }

  /* ---------- 供应商 ---------- */

  listProviders(): ProviderDef[] {
    try {
      return JSON.parse(readFileSync(this.providersFile, 'utf8')) as ProviderDef[]
    } catch {
      return []
    }
  }

  getProvider(id: string): ProviderDef | undefined {
    return this.listProviders().find((p) => p.id === id)
  }

  saveProviders(providers: ProviderDef[]): void {
    writeFileSync(this.providersFile, JSON.stringify(providers, null, 2), 'utf8')
  }

  addProvider(input: Omit<ProviderDef, 'createdAt'>): ProviderDef {
    const providers = this.listProviders()
    const id = input.id.trim().toLowerCase()
    const existing = providers.find((p) => p.id === id)
    const entry: ProviderDef = { ...input, id, createdAt: existing?.createdAt ?? Date.now() }
    const next = existing ? providers.map((p) => (p.id === id ? entry : p)) : [...providers, entry]
    this.saveProviders(next)
    return entry
  }

  removeProvider(id: string): boolean {
    const providers = this.listProviders()
    const next = providers.filter((p) => p.id !== id)
    if (next.length === providers.length) return false
    this.saveProviders(next)
    // 若删除的是当前默认，清空默认引用
    const settings = this.loadSettings()
    if (settings.providerId === id) this.saveSettings({ ...settings, providerId: '', model: '' })
    return true
  }

  /* ---------- 运行设置 ---------- */

  loadSettings(): RuntimeSettings {
    try {
      return { ...DEFAULT_SETTINGS, ...(JSON.parse(readFileSync(this.settingsFile, 'utf8')) as Partial<RuntimeSettings>) }
    } catch {
      return { ...DEFAULT_SETTINGS }
    }
  }

  saveSettings(settings: RuntimeSettings): void {
    writeFileSync(this.settingsFile, JSON.stringify(settings, null, 2), 'utf8')
  }

  /** 解析工作区绝对路径（为空则回退到 config 的 workspaceRoot）。 */
  resolveWorkspace(fallback: string): string {
    const ws = this.loadSettings().workspace.trim()
    return ws !== '' ? resolve(ws) : fallback
  }

  /** 当前选中的供应商（未选或不存在则 undefined）。 */
  activeProvider(): ProviderDef | undefined {
    const settings = this.loadSettings()
    return this.getProvider(settings.providerId)
  }

  /** 当前选中模型（设置里的模型 > 供应商默认 > 供应商目录第一个）。 */
  activeModel(): string {
    const settings = this.loadSettings()
    const provider = this.activeProvider()
    if (settings.model) return settings.model
    if (provider?.model) return provider.model
    if (provider?.models.length) return provider.models[0]!
    return ''
  }

  /** 基于运行时供应商/设置解析 LLM 配置（有自定义供应商则优先，否则回退 DSH/env）。 */
  resolveLlm(cfg: AgentConfig, mock = false): LlmConfig {
    if (mock || process.env.DSH_LLM_PROVIDER === 'mock') {
      return { provider: 'mock', baseURL: '', apiKey: undefined, model: 'mock-model', maxTokens: cfg.llm.maxTokens, timeoutMs: cfg.llm.timeoutMs, temperature: cfg.llm.temperature }
    }
    const provider = this.activeProvider()
    const settings = this.loadSettings()
    if (provider && provider.baseURL) {
      return {
        provider: provider.id,
        baseURL: provider.baseURL.replace(/\/+$/, ''),
        apiKey: provider.apiKey || undefined,
        model: this.activeModel() || cfg.llm.model,
        maxTokens: settings.maxTokens || cfg.llm.maxTokens,
        timeoutMs: cfg.llm.timeoutMs,
        temperature: settings.temperature ?? cfg.llm.temperature,
      }
    }
    return resolveLlmConfig(cfg, false)
  }
}
