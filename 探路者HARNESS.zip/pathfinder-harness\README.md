# 探路者HARNESS —— 智能 Agent 系统

一个功能完备、可扩展、具有**反馈记忆能力**的智能 Agent 系统。基于 DeepSeek Harness（DSH）架构思想实现，零运行时依赖，Node ≥ 24 原生运行 TypeScript（无需构建）。

## 特性

- **核心循环**：感知 → 规划 → 行动 → 观察（Plan-and-Execute），支持多轮对话、超时/错误重试、优雅降级
- **任务规划**：复杂请求拆解为子任务，失败自动重规划/跳过，优先级排序
- **工具调用**：6 个内置工具（计算器/搜索模拟/天气/文件读写/数据库查询模拟），JSON Schema 定义，并行执行，权限审批
- **反思与自我修正**：每步行动生成反思日志，失败自动触发一次修正，教训晋升长期记忆
- **上下文管理**：Token 估算、超预算自动摘要（失败降级截断）、手动清除/重置
- **流式输出与中断**：SSE 流式响应，前端停止按钮
- **反馈记忆**：长期记忆/偏好/教训统一为**一篇可复制、可直接编辑的浓缩提示词**（txt 式），反馈驱动自动追加
- **自定义模型供应商**：Web 控制台「设置」里像 DSH 一样配置 Provider ID / 显示名称 / API 地址 / 协议 / API 密钥 / 模型目录，并可指定工作区
- **苹果风格 Web 控制台**：毛玻璃导航、流式光标、工具调用卡片、反馈按钮、记忆面板、供应商/工作区设置、响应式

## 快速开始

要求：**Node ≥ 24**（本机已是 v24.19.0）。

```bash
cd pathfinder-harness

# 1) 零依赖演示（mock 模型，完整链路：规划→工具→反思→回复）
npm run demo

# 2) 真实模型（三种方式任选）
#   a. 复用 $DSH_HOME/settings.yaml + 环境变量（自动）
#   b. 环境变量 DSH_LLM_API_KEY（OpenAI 兼容 key）
#   c. Web 控制台「设置」→ 添加供应商（Provider ID/API 地址/密钥/模型目录）
$env:DSH_LLM_API_KEY = "sk-..."      # 七牛云/DeepSeek 等 OpenAI 兼容 key
node src/main.ts ask "帮我算一下 123*45+678，再查一下北京天气"

# 3) 启动 Web 控制台
npm start          # 或 node src/main.ts serve [--mock]
# 浏览器打开 http://127.0.0.1:3088
# 左侧「设置」标签：添加自定义供应商 + 指定工作区 + 选默认模型
```

## CLI 命令

```
node src/main.ts ask "任务" [--resume <id>] [--mock] [--yes]    # 对话
node src/main.ts serve [--port N] [--mock]                       # Web 控制台
node src/main.ts memory [--all]                                  # 查看长期记忆（单篇提示词）
node src/main.ts feedback <sid> <mid> up|down|delete [--note]    # 反馈
node src/main.ts sessions                                        # 会话列表
```

## 反馈记忆闭环（核心能力）

```bash
# 1) 对话
node src/main.ts ask "帮我查一下北京天气"

# 2) 对最后一条回复点踩并给评语（自动提取偏好）
node src/main.ts feedback <sessionId> <messageId> down --note "以后回答请更简洁"

# 3) 查看已积累的记忆/偏好
node src/main.ts memory

# 4) 继续同一会话 —— 偏好注入，模型行为改变
node src/main.ts ask --resume <sessionId> "再回答一次"
```

## 项目结构

```
pathfinder-harness/
├── config/agent.yml        # 示例配置（persona/llm/tools/planning/memory/context/server）
├── src/
│   ├── main.ts             # CLI 入口（ask/serve/memory/feedback/sessions）
│   ├── server.ts           # HTTP + SSE 服务器（流式/中断/反馈/记忆/供应商/设置 API）
│   ├── agent.ts            # 核心循环：感知-规划-行动-观察 + 重试 + 优雅降级
│   ├── planner.ts          # 任务规划（Plan-and-Execute + 重规划 + 优先级）
│   ├── reflection.ts       # 反思与自我修正
│   ├── context.ts          # 上下文管理（token 估算 + 自动摘要）
│   ├── tools.ts            # 工具注册表 + 6 工具 + 并行 + 权限
│   ├── memory.ts           # 长期记忆（单篇提示词）+ 偏好提取 + 反馈 sidecar + 反思
│   ├── runtime.ts          # 运行时供应商注册表 + 运行设置（工作区/模型/温度/token）
│   ├── session.ts          # 会话 + JSONL 持久化
│   ├── llm.ts              # LLM 客户端（流式 SSE + 可编程 mock）
│   ├── config.ts           # 分层配置（环境变量 > DSH settings > agent.yml > 默认）
│   └── yaml-mini.ts        # 零依赖 YAML 子集解析器
├── web/                    # 苹果风格控制台（index.html / style.css / app.js）
├── tests/                  # node:test 单元 + 集成 + E2E 测试
├── ITERATIONS.md           # 测试迭代记录（≥3 轮）
└── README.md
```

## 测试

```bash
npm test               # 66 个测试（单元 + 集成 + E2E）
npm run test:coverage  # 附带覆盖率报告（行覆盖率 ≥ 80%）
```

覆盖维度：

| 层级 | 文件 | 覆盖内容 |
|---|---|---|
| 单元 | tools.test.ts | 工具正确性/权限/并行/越界 |
| 单元 | memory.test.ts | 单篇记忆读写/编辑/清空/偏好提取/CAS/反思晋升 |
| 单元 | planner.test.ts | 计划解析/优先级/重规划/降级 |
| 单元 | context.test.ts | token 估算/摘要/降级截断 |
| 单元 | runtime.test.ts | 供应商增删查/工作区/模型选择/LLM 解析优先级 |
| 单元+集成 | agent.test.ts | 核心循环/工具选择/反思/中断/多轮 |
| 集成 | server.test.ts | HTTP/SSE/反馈/记忆/供应商/设置/停止 |
| E2E | e2e.test.ts | 完整对话流程/记忆注入/流式/中断 |

## 配置（config/agent.yml）

```yaml
persona: |                      # 系统人设
llm:                            # 模型路由（auto=复用 DSH 配置）
  provider: auto                #   auto | openai-completions | mock
  model: auto
  baseURL: auto
  apiKeyEnv: auto
tools:
  enabled: [calculator, web_search, weather, file_read, file_write, db_query]
  requireApproval: [file_write]  # 需用户确认的工具
planning:
  maxSteps: 10                   # 单回合最多步骤
  maxReplans: 2                  # 失败重规划上限
memory:
  inject: true                   # 长期记忆/偏好注入 system prompt
  maxInjectedItems: 10
context:
  tokenBudget: 8000
  summarizeThreshold: 0.7        # 超 70% 自动摘要
server:
  host: 127.0.0.1
  port: 3088
```

## API（Web 控制台）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/api/state` | 会话/记忆文本/反思/计划/供应商/设置/模型 汇总 |
| GET | `/api/memory` | 单篇记忆文本 `{prompt}` |
| GET | `/api/providers` | 供应商列表（密钥脱敏）+ 当前设置 |
| GET | `/api/history?id=` | 会话消息历史 |
| POST | `/api/chat` | 发送消息（SSE 流式） |
| POST | `/api/stop` | 中断进行中的请求 |
| POST | `/api/feedback` | 记录反馈（up/down + note） |
| POST | `/api/memory` | 记忆编辑 `{action:'save',text}` / `{action:'clear'}` |
| POST | `/api/providers` | 供应商 `{action:'add',provider}` / `{action:'remove',id}` |
| POST | `/api/settings` | 运行设置（工作区/供应商/模型/温度/token） |
| POST | `/api/clear` `/api/reset` | 清上下文/重置会话 |

## 技术栈

- **语言**：TypeScript（仅 erasable syntax，无 enum/namespace/参数属性）
- **运行时**：Node ≥ 24 原生类型剥离，`node src/main.ts` 直接运行，**无构建步骤**
- **依赖**：零运行时依赖（YAML 解析器、LLM 客户端、HTTP/SSE 服务器、前端全部手写）
- **测试**：`node:test`（Node 内置），零依赖
- **前端**：原生 HTML/CSS/JS，苹果设计语言（毛玻璃、大圆角、系统字体栈、#0071e3）

## 反馈记忆设计

反馈记忆 = **存储层 + 注入层**（对标 DSH `dsh-message-feedback` 的 sidecar 模型 + 增强注入）：

1. 用户点 👍/👎 + 评语 → `data/feedback/<sid>.json`（CAS 版本控制）
2. 评语经规则提取为用户偏好 → 追加为记忆提示词的一行
3. 用户明说「记住…」→ 提取为长期事实，追加一行
4. 失败反思的教训 → 追加为记忆提示词的一行
5. 全部长期记忆 = **一篇纯文本** `data/memory/prompt.txt`，每行一条（`- [事实] …` / `- [用户偏好] …` / `- [教训] …`）
6. 前端「记忆」标签以单个 textarea 展示，可**复制、直接编辑、保存、清空**
7. 下次对话时，整篇文本包裹为 `<memory>` 块注入 system prompt

DSH 原版的反馈**不进模型上下文**（仅供 UI），本系统在其上增加了「注入」层，实现真正的"根据反馈优化行为"。

## 自定义供应商与工作区（Web 控制台「设置」）

像 DSH 一样，在左侧「设置」标签配置模型接入，配置持久化到 `data/providers.json` + `data/settings.json`（`data/` 已 gitignore）：

- **Provider ID**：小写开头的唯一标识（如 `acme-gateway`）
- **显示名称 / API 地址 / API 协议 / API 密钥 / 模型目录**：一次填齐，密钥在前端仅显示后 4 位
- **工作区**：文件工具（file_read/file_write）的活动根目录，为空则回退 `config/agent.yml` 的 `tools.workspaceRoot`
- **默认模型 / 温度 / 最大 Token**：运行时即时生效，下次对话按新配置发起

解析优先级：**运行时供应商（Web 配置） > 环境变量/DSH settings > agent.yml > 默认**。
