/**
 * context.test.ts —— 上下文管理单元测试
 * 覆盖：token 估算（CJK/ASCII）、超预算自动摘要、摘要失败降级截断。
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { Session } from '../src/session.ts'
import { estimateTokens, estimateSessionTokens, maybeSummarize } from '../src/context.ts'

function makeSession() {
  const s = new Session({ version: 1, id: 's1', createdAt: Date.now() })
  for (let i = 0; i < 12; i++) s.append('user', [{ type: 'text', text: `第${i}轮 这是用户说的一段话，内容比较长`.repeat(2) }], { kind: 'user' })
  return s
}

test('estimateTokens：CJK 按字、ASCII 按 4 字符', () => {
  assert.equal(estimateTokens('中文'), 2)
  assert.equal(estimateTokens('abcd'), 1)
  assert.equal(estimateTokens('hello'), 2) // ceil(5/4)
})

test('maybeSummarize：超预算时压缩为摘要消息', async () => {
  const session = makeSession()
  const before = session.messages.length
  const result = await maybeSummarize(
    session,
    { tokenBudget: 100, summarizeThreshold: 0.5 },
    '',
    async (messages) => `摘要：共 ${messages.length} 条消息，讨论了一些事情`,
    6,
  )
  assert.equal(result.summarized, true)
  assert.ok(session.messages.length < before)
  const first = session.messages[0]!
  assert.equal(first.role, 'user')
  assert.match(first.content[0]!.text ?? '', /<context-summary>/)
})

test('maybeSummarize：摘要失败时降级为截断', async () => {
  const session = makeSession()
  const before = session.messages.length
  const result = await maybeSummarize(session, { tokenBudget: 50, summarizeThreshold: 0.5 }, '', async () => {
    throw new Error('summary failed')
  }, 6)
  assert.equal(result.summarized, true)
  assert.ok(session.messages.length < before)
  assert.ok(session.messages.length > 0)
})

test('maybeSummarize：未超预算时不动作', async () => {
  const session = makeSession()
  const before = session.messages.length
  const result = await maybeSummarize(session, { tokenBudget: 1_000_000, summarizeThreshold: 0.5 }, '', async () => '不应调用')
  assert.equal(result.summarized, false)
  assert.equal(session.messages.length, before)
})

test('estimateSessionTokens：随消息数增长', () => {
  const session = makeSession()
  const half = new Session({ version: 1, id: 's2', createdAt: Date.now() }, session.messages.slice(0, 4))
  assert.ok(estimateSessionTokens(session) > estimateSessionTokens(half))
})
