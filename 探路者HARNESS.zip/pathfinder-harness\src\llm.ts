/**
 * llm —— LLM 客户端（对应 DSH: dsh-llm + adapter）。
 *
 * - chatStream：OpenAI 兼容 /chat/completions 流式（SSE），onDelta 逐 token 回调，支持 AbortSignal 中断
 * - chat：非流式（内部复用 chatStream 累积）
 * - MockLlm：可编程模拟模型（测试 + 无 key 演示），支持脚本化多轮、工具调用、分块流式
 */

export interface ToolSchema {
  name: string
  description: string
  parameters: Record<string, unknown>
}

export interface ToolCall {
  id: string
  name: string
  /** 模型返回的原始 JSON 字符串参数 */
  arguments: string
}

export interface LlmUsage {
  inputTokens: number
  outputTokens: number
}

export interface LlmResponse {
  content: string
  toolCalls: ToolCall[]
  finishReason: string
  usage?: LlmUsage
}

/** OpenAI wire 格式消息。 */
export interface WireMessage {
  role: 'system' | 'user' | 'assistant' | 'tool'
  content: string | null
  tool_calls?: Array<{ id: string; type: 'function'; function: { name: string; arguments: string } }>
  tool_call_id?: string
}

export interface ChatRequest {
  baseURL: string
  apiKey: string | undefined
  model: string
  system: string
  messages: WireMessage[]
  tools?: ToolSchema[]
  maxTokens?: number
  timeoutMs?: number
  temperature?: number
}

export class LlmError extends Error {
  readonly status: number | undefined

  constructor(message: string, status?: number) {
    super(message)
    this.status = status
  }
}

/** 流式回调。 */
export interface StreamHandlers {
  /** 每个文本增量 */
  onDelta?: (text: string) => void
  /** 每个推理增量（reasoning 模型） */
  onReasoning?: (text: string) => void
  /** 工具调用出现时（整个对象） */
  onToolCall?: (call: ToolCall) => void
}

interface DeltaChunk {
  choices?: Array<{
    delta?: { content?: string | null; reasoning_content?: string | null; tool_calls?: Array<{ index?: number; id?: string; function?: { name?: string; arguments?: string } }> }
    finish_reason?: string | null
  }>
  usage?: { prompt_tokens?: number; completion_tokens?: number }
}

/** 流式调用 chat/completions。signal 中断时抛 AbortError（内容保留在已回调的 delta 中）。 */
export async function chatStream(request: ChatRequest, handlers: StreamHandlers = {}, signal?: AbortSignal): Promise<LlmResponse> {
  if (!request.apiKey) {
    throw new LlmError('LLM API key 未配置：设置 DSH_LLM_API_KEY / DEEPSEEK_API_KEY 环境变量，或在 $DSH_HOME/.credentials.yaml 提供。')
  }
  const controller = new AbortController()
  const onAbort = () => controller.abort()
  signal?.addEventListener('abort', onAbort)
  const timer = setTimeout(() => controller.abort(), request.timeoutMs ?? 120000)
  try {
    const body: Record<string, unknown> = {
      model: request.model,
      messages: [{ role: 'system', content: request.system }, ...request.messages],
      max_tokens: request.maxTokens ?? 2048,
      temperature: request.temperature,
      stream: true,
    }
    if (request.tools && request.tools.length > 0) {
      body.tools = request.tools.map((t) => ({ type: 'function', function: t }))
      body.tool_choice = 'auto'
    }
    const res = await fetch(`${request.baseURL}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${request.apiKey}` },
      body: JSON.stringify(body),
      signal: controller.signal,
    })
    if (!res.ok) {
      const text = await res.text().catch(() => '')
      throw new LlmError(`LLM HTTP ${res.status}: ${text.slice(0, 300)}`, res.status)
    }
    if (!res.body) throw new LlmError('LLM response has no body')

    // —— 手动解析 OpenAI SSE 流 ——
    const reader = res.body.getReader()
    const decoder = new TextDecoder()
    let buffer = ''
    let content = ''
    let reasoning = ''
    let finishReason = 'stop'
    let usage: LlmUsage | undefined
    const toolCalls = new Map<number, { id: string; name: string; arguments: string }>()

    const handleChunk = (chunk: DeltaChunk) => {
      const choice = chunk.choices?.[0]
      if (choice?.delta?.reasoning_content) {
        reasoning += choice.delta.reasoning_content
        handlers.onReasoning?.(choice.delta.reasoning_content)
      }
      if (choice?.delta?.content) {
        content += choice.delta.content
        handlers.onDelta?.(choice.delta.content)
      }
      for (const tc of choice?.delta?.tool_calls ?? []) {
        const index = tc.index ?? 0
        const entry = toolCalls.get(index) ?? { id: '', name: '', arguments: '' }
        if (tc.id) entry.id = tc.id
        if (tc.function?.name) entry.name += tc.function.name
        if (tc.function?.arguments) entry.arguments += tc.function.arguments
        toolCalls.set(index, entry)
      }
      if (choice?.finish_reason) finishReason = choice.finish_reason
      if (chunk.usage) usage = { inputTokens: chunk.usage.prompt_tokens ?? 0, outputTokens: chunk.usage.completion_tokens ?? 0 }
    }

    for (;;) {
      const { done, value } = await reader.read()
      if (done) break
      buffer += decoder.decode(value, { stream: true })
      let nl
      while ((nl = buffer.indexOf('\n\n')) >= 0) {
        const frame = buffer.slice(0, nl)
        buffer = buffer.slice(nl + 2)
        for (const line of frame.split('\n')) {
          const trimmed = line.trim()
          if (!trimmed.startsWith('data:')) continue
          const payload = trimmed.slice(5).trim()
          if (payload === '[DONE]') continue
          try {
            handleChunk(JSON.parse(payload) as DeltaChunk)
          } catch {
            // 忽略无法解析的帧（网络半帧）
          }
        }
      }
    }

    const calls: ToolCall[] = [...toolCalls.entries()]
      .sort(([a], [b]) => a - b)
      .map(([, v]) => ({ id: v.id, name: v.name, arguments: v.arguments }))
    return { content, toolCalls: calls, finishReason, usage }
  } catch (error) {
    if (controller.signal.aborted && !signal?.aborted) throw new LlmError(`LLM 超时（${request.timeoutMs ?? 120000}ms）`)
    throw error
  } finally {
    clearTimeout(timer)
    signal?.removeEventListener('abort', onAbort)
  }
}

/** 非流式调用（内部复用流式）。 */
export async function chat(request: ChatRequest, signal?: AbortSignal): Promise<LlmResponse> {
  return chatStream(request, {}, signal)
}

/** 容错解析工具参数 JSON（模型可能输出注释/尾逗号/包裹文本）。 */
export function parseToolArguments(raw: string): Record<string, unknown> {
  try {
    return JSON.parse(raw) as Record<string, unknown>
  } catch {
    const cleaned = raw.replace(/\/\/.*$/gm, '').replace(/,\s*([}\]])/g, '$1').trim()
    try {
      return JSON.parse(cleaned) as Record<string, unknown>
    } catch {
      return {}
    }
  }
}

/* ------------------------------------------------------------------ */
/* MockLlm：可编程模拟模型                                              */
/* ------------------------------------------------------------------ */

export interface MockExchange {
  /** 匹配条件：消息内容包含该子串时返回此条（默认总是匹配） */
  match?: string
  content?: string
  toolCalls?: ToolCall[]
  /** 分块大小（模拟流式，默认按 content 整块） */
  chunkSize?: number
}

/**
 * 可编程 mock：按 script 顺序消费，耗尽后重复最后一条。
 * 用于单元测试（注入精确脚本）与无 key 演示（内置默认脚本）。
 */
export class MockLlm {
  private index = 0
  private readonly script: MockExchange[]

  constructor(script: MockExchange[]) {
    this.script = script
    if (script.length === 0) throw new Error('MockLlm script must not be empty')
  }

  private next(messages: WireMessage[]): MockExchange {
    const entry = this.script[Math.min(this.index, this.script.length - 1)]
    const tail = messages.map((m) => m.content ?? '').join('\n').slice(-2000)
    for (let i = this.index; i < this.script.length; i++) {
      const candidate = this.script[i]!
      if (!candidate.match || tail.includes(candidate.match)) {
        this.index = i + 1
        return candidate
      }
    }
    return entry!
  }

  async complete(request: ChatRequest, handlers: StreamHandlers = {}, signal?: AbortSignal): Promise<LlmResponse> {
    const entry = this.next(request.messages)
    const chunkSize = entry.chunkSize ?? Math.max(1, Math.ceil((entry.content ?? '').length / 8))
    for (let i = 0; i < (entry.content ?? '').length; i += chunkSize) {
      if (signal?.aborted) {
        const error = new Error('aborted')
        error.name = 'AbortError'
        throw error
      }
      const piece = (entry.content ?? '').slice(i, i + chunkSize)
      handlers.onDelta?.(piece)
      await new Promise((r) => setTimeout(r, 2))
    }
    return {
      content: entry.content ?? '',
      toolCalls: entry.toolCalls ?? [],
      finishReason: entry.toolCalls?.length ? 'tool_calls' : 'stop',
      usage: { inputTokens: 1, outputTokens: 1 },
    }
  }

  async stream(request: ChatRequest, handlers: StreamHandlers = {}, signal?: AbortSignal): Promise<LlmResponse> {
    return this.complete(request, handlers, signal)
  }
}

/** 演示用默认脚本：规划 JSON + 按关键词调用工具 + 总结。 */
export function demoMockScript(): MockExchange[] {
  return [
    {
      match: '分步计划',
      content: JSON.stringify({
        steps: [
          { id: 1, title: '计算 123*45+678', tool: 'calculator', priority: 1, status: 'pending' },
          { id: 2, title: '查询北京天气', tool: 'weather', priority: 2, status: 'pending' },
          { id: 3, title: '汇总结果', tool: null, priority: 3, status: 'pending' },
        ],
      }),
    },
    { match: '算', toolCalls: [{ id: 'mc-1', name: 'calculator', arguments: '{"expression":"123*45+678"}' }] },
    { match: '天气', toolCalls: [{ id: 'mc-2', name: 'weather', arguments: '{"city":"北京"}' }] },
    {
      content:
        '已按计划完成：\n1. 计算结果：123*45+678 = 6213\n2. 北京天气：已查询（见上方结果）\n3. 汇总：任务全部完成。\n\n这是 mock 模式的演示回复，配置真实 key 后可获得完整智能回复。',
    },
  ]
}
