/**
 * memory.test.ts —— 记忆系统单元测试（单篇浓缩提示词模型）
 * 覆盖：整篇读写/编辑/清空、追加去重、偏好提取、显式记忆指令提取、反馈 CAS、反思晋升、记忆块渲染。
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { MemoryStore, extractPreferenceFromNote, extractFactsFromMessage } from '../src/memory.ts'

function makeStore() {
  return new MemoryStore(mkdtempSync(join(tmpdir(), 'sa-mem-')), { maxNoteBytes: 8192 })
}

test('长期记忆：追加后写入整篇文本并可检索', () => {
  const store = makeStore()
  store.addMemory('fact', '用户住在北京', 's1', 'user-explicit')
  store.addMemory('preference', '用户喜欢简洁回答', 's1', 'feedback')
  const prompt = store.getPrompt()
  assert.match(prompt, /\[事实\] 用户住在北京/)
  assert.match(prompt, /\[用户偏好\] 用户喜欢简洁回答/)
})

test('记忆编辑：整篇覆盖保存', () => {
  const store = makeStore()
  store.setPrompt('- [事实] 手动编辑的内容\n')
  assert.equal(store.getPrompt(), '- [事实] 手动编辑的内容')
})

test('记忆清空：clear 后为空', () => {
  const store = makeStore()
  store.addMemory('fact', '待清空', 's1')
  store.clear()
  assert.equal(store.getPrompt(), '')
})

test('追加去重：完全相同的内容不重复写入', () => {
  const store = makeStore()
  store.addMemory('fact', '用户在北京', 's1')
  store.addMemory('fact', '用户在北京', 's1')
  const lines = store.getPrompt().split('\n').filter((l) => l.trim() !== '')
  assert.equal(lines.length, 1)
})

test('偏好提取：负面反馈 + 评语', () => {
  assert.match(extractPreferenceFromNote('以后请更简洁', 'negative')!, /简洁/)
})

test('偏好提取：正面反馈含意图关键词', () => {
  assert.match(extractPreferenceFromNote('请一直保持这种风格', 'positive')!, /保持/)
})

test('显式记忆指令：从消息提取「记住…」', () => {
  const facts = extractFactsFromMessage('记住我喜欢喝咖啡。另外请记住我住在上海。')
  assert.equal(facts.length, 2)
  assert.equal(facts[0], '我喜欢喝咖啡')
  assert.equal(facts[1], '我住在上海')
})

test('反馈 CAS：同版本写入冲突被拒绝', () => {
  const store = makeStore()
  const first = store.putFeedback('s1', { messageId: 'm-1', rating: 'positive', ifVersion: null })
  assert.equal(first.ok, true)
  const conflict = store.putFeedback('s1', { messageId: 'm-1', rating: 'negative', ifVersion: 'stale-version' })
  assert.equal(conflict.ok, false)
  if (!conflict.ok) assert.equal(conflict.code, 'version-conflict')
})

test('反馈 CAS：正确版本可更新', () => {
  const store = makeStore()
  const first = store.putFeedback('s1', { messageId: 'm-1', rating: 'positive', ifVersion: null })
  assert.equal(first.ok, true)
  if (first.ok) {
    const update = store.putFeedback('s1', { messageId: 'm-1', rating: 'negative', note: '太啰嗦', ifVersion: first.item.version })
    assert.equal(update.ok, true)
    if (update.ok) assert.equal(update.item.rating, 'negative')
  }
})

test('反馈评语超长被拒绝', () => {
  const store = new MemoryStore(mkdtempSync(join(tmpdir(), 'sa-mem2-')), { maxNoteBytes: 10 })
  const r = store.putFeedback('s1', { messageId: 'm-1', rating: 'positive', note: 'x'.repeat(100), ifVersion: null })
  assert.equal(r.ok, false)
})

test('反思：失败教训晋升为长期记忆', () => {
  const store = makeStore()
  store.addReflection({ sessionId: 's1', turn: 1, step: 1, action: 'calculator', ok: false, reason: '表达式非法', adjustment: '修正参数后重试' })
  store.promoteReflection('s1')
  assert.match(store.getPrompt(), /\[教训\] 在calculator时曾失败/)
})

test('buildMemoryBlock：非空时渲染 <memory> 包裹块，空时返回空串', () => {
  const store = makeStore()
  assert.equal(store.buildMemoryBlock(10), '')
  store.addMemory('fact', '用户在北京', 's1', 'user-explicit')
  const block = store.buildMemoryBlock(10)
  assert.match(block, /<memory>/)
  assert.match(block, /用户在北京/)
  assert.match(block, /<\/memory>/)
})
