/* ============================================================
   探路者HARNESS 控制台前端逻辑
   - 会话管理、SSE 流式聊天、工具卡片、反馈、记忆面板、设置
   - 无框架，原生 JS + fetch（ReadableStream 解析 SSE）
   ============================================================ */

const $ = (sel) => document.querySelector(sel);

const state = {
  currentSessionId: null,
  abortController: null,
  streaming: false,
};

/* ---------------- Toast ---------------- */
let toastTimer;
function toast(message) {
  const el = $('#toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
}

/* ---------------- 侧边栏 ---------------- */
function toggleSidebar(open) {
  $('#sidebar').classList.toggle('open', open);
  $('#sidebarBackdrop').classList.toggle('show', open);
}
$('#hamburger').addEventListener('click', () => toggleSidebar(!$('#sidebar').classList.contains('open')));
$('#sidebarBackdrop').addEventListener('click', () => toggleSidebar(false));

document.querySelectorAll('.sidebar-tabs .tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.sidebar-tabs .tab').forEach((t) => t.classList.toggle('active', t === tab));
    document.querySelectorAll('.tab-panel').forEach((p) => p.classList.toggle('active', p.id === `panel-${tab.dataset.tab}`));
    if (tab.dataset.tab === 'memory') loadMemory();
    if (tab.dataset.tab === 'settings') loadState();
  });
});

/* ---------------- 消息渲染 ---------------- */
function addMessage(role, text) {
  $('#emptyState')?.remove();
  const wrap = document.createElement('div');
  wrap.className = `msg ${role}`;
  const bubble = document.createElement('div');
  bubble.className = 'bubble';
  if (text) bubble.textContent = text;
  wrap.appendChild(bubble);
  $('#messages').appendChild(wrap);
  scrollBottom();
  return bubble;
}

function appendStreamingText(bubble, text) {
  const cursor = bubble.querySelector('.cursor-blink');
  if (cursor) cursor.remove();
  bubble.append(document.createTextNode(text));
  const c = document.createElement('span');
  c.className = 'cursor-blink';
  bubble.appendChild(c);
  scrollBottom();
}

function finalizeBubble(bubble, text) {
  const cursor = bubble.querySelector('.cursor-blink');
  if (cursor) cursor.remove();
  if (text && !bubble.textContent) bubble.textContent = text;
  // 追加反馈按钮
  const wrap = bubble.parentElement;
  if (wrap && !wrap.querySelector('.feedback-row')) {
    const row = document.createElement('div');
    row.className = 'feedback-row';
    row.innerHTML = `
      <button class="feedback-btn up" title="赞同">👍</button>
      <button class="feedback-btn down" title="反对">👎</button>`;
    row.querySelector('.up').addEventListener('click', () => vote('positive', row));
    row.querySelector('.down').addEventListener('click', () => vote('negative', row));
    wrap.appendChild(row);
  }
}

function addToolCard(bubble, detail) {
  const card = document.createElement('div');
  card.className = 'tool-card';
  card.dataset.callId = detail.callId || '';
  card.innerHTML = `
    <div class="tool-head"><span class="spinner"></span><span class="tool-name">正在调用 ${detail.name}…</span></div>`;
  bubble.appendChild(card);
  scrollBottom();
  return card;
}

function updateToolCard(bubble, detail) {
  const card = bubble.querySelector(`.tool-card[data-call-id="${detail.callId}"]`) || bubble.querySelector('.tool-card:not(.done):not(.failed)');
  if (!card) return;
  const head = card.querySelector('.tool-head');
  const nameEl = card.querySelector('.tool-name');
  head.classList.remove('done', 'failed');
  if (detail.denied) {
    head.classList.add('failed');
    nameEl.textContent = `🚫 ${detail.name}（用户拒绝）`;
  } else if (detail.ok) {
    head.classList.add('done');
    nameEl.textContent = `✓ ${detail.name} 完成`;
  } else {
    head.classList.add('failed');
    nameEl.textContent = `✗ ${detail.name} 失败`;
  }
  head.querySelector('.spinner')?.remove();
  const body = document.createElement('div');
  body.className = 'tool-body';
  body.textContent = detail.output || '(无输出)';
  card.appendChild(body);
  scrollBottom();
}

function addReflectionTag(bubble, text) {
  const tag = document.createElement('div');
  tag.className = 'reflection-tag';
  tag.textContent = `💭 ${text}`;
  bubble.appendChild(tag);
}

function scrollBottom() {
  const m = $('#messages');
  m.scrollTop = m.scrollHeight;
}

/* ---------------- 发送消息 / SSE ---------------- */
function setSendState(mode) {
  const btn = $('#send');
  const input = $('#input');
  if (mode === 'streaming') {
    state.streaming = true;
    btn.classList.add('stop');
    $('.send-label').style.display = 'none';
    $('.send-stop').style.display = 'inline';
    btn.disabled = false;
  } else {
    state.streaming = false;
    btn.classList.remove('stop');
    $('.send-label').style.display = 'inline';
    $('.send-stop').style.display = 'none';
    btn.disabled = input.value.trim() === '';
  }
}

async function sendMessage(text) {
  text = text.trim();
  if (!text || state.streaming) return;
  addMessage('user', text);
  $('#input').value = '';
  const bubble = addMessage('agent', '');
  setSendState('streaming');
  state.abortController = new AbortController();

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId: state.currentSessionId, message: text }),
      signal: state.abortController.signal,
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: `HTTP ${res.status}` }));
      throw new Error(err.error || `HTTP ${res.status}`);
    }
    if (res.headers.get('content-type')?.includes('text/event-stream')) {
      await readSSE(res, bubble);
    } else {
      const data = await res.json();
      finalizeBubble(bubble, data.text || data.error);
    }
  } catch (error) {
    if (error.name === 'AbortError') {
      bubble.querySelector('.cursor-blink')?.remove();
      if (!bubble.textContent.trim()) bubble.textContent = '（已停止）';
      finalizeBubble(bubble, bubble.textContent);
    } else {
      finalizeBubble(bubble, '发生错误：' + error.message);
    }
  } finally {
    setSendState('idle');
    state.abortController = null;
    await refreshSessions();
    loadMemory();
  }
}

async function readSSE(res, bubble) {
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let finalText = '';
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let idx;
    while ((idx = buffer.indexOf('\n\n')) >= 0) {
      const frame = buffer.slice(0, idx);
      buffer = buffer.slice(idx + 2);
      const parsed = parseFrame(frame);
      if (!parsed) continue;
      const { event, data } = parsed;
      if (event === 'delta') {
        appendStreamingText(bubble, data.text || '');
      } else if (event === 'event') {
        handleAgentEvent(bubble, data);
      } else if (event === 'done') {
        finalText = data.text || '';
      } else if (event === 'error') {
        throw new Error(data.error || 'unknown error');
      } else if (event === 'approval') {
        addReflectionTag(bubble, `🔐 需确认工具 ${data.name}`);
      }
    }
  }
  finalizeBubble(bubble, finalText);
}

function parseFrame(frame) {
  const lines = frame.split('\n');
  let event = 'message';
  const dataLines = [];
  for (const line of lines) {
    if (line.startsWith('event:')) event = line.slice(6).trim();
    else if (line.startsWith('data:')) dataLines.push(line.slice(5).trim());
  }
  if (dataLines.length === 0) return null;
  try {
    return { event, data: JSON.parse(dataLines.join('\n')) };
  } catch {
    return { event, data: {} };
  }
}

function handleAgentEvent(bubble, ev) {
  switch (ev.type) {
    case 'tool/call':
      addToolCard(bubble, ev.detail || {});
      break;
    case 'tool/result':
      updateToolCard(bubble, ev.detail || {});
      break;
    case 'reflection': {
      const d = ev.detail || {};
      if (d.action) addReflectionTag(bubble, `${d.action} ${d.ok ? '有效' : '无效'}`);
      else if (typeof d === 'string') addReflectionTag(bubble, d);
      break;
    }
    case 'correction':
      addReflectionTag(bubble, `🔁 自我修正：${ev.detail || ''}`);
      break;
    case 'context/summarized':
      toast(String(ev.detail || '上下文已压缩'));
      break;
    case 'plan/created': {
      const steps = (ev.detail && ev.detail.steps) || [];
      if (steps.length) addReflectionTag(bubble, `📋 计划：${steps.map((s) => s.title).join(' → ')}`);
      break;
    }
    case 'error':
      addReflectionTag(bubble, `⚠ ${ev.detail || ''}`);
      break;
    case 'interrupted':
      addReflectionTag(bubble, '⏹ 已中断');
      break;
  }
}

/* ---------------- 反馈 ---------------- */
async function vote(rating, row) {
  const wrap = row.parentElement;
  const msg = wrap;
  // 找到该消息在会话中的索引（粗略：用当前会话最近一条助手消息）
  if (!state.currentSessionId) {
    toast('请先发送一条消息再反馈');
    return;
  }
  const note = rating === 'negative' ? prompt('可以告诉我哪里不满意吗？（可选）') : undefined;
  const res = await fetch('/api/feedback', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sessionId: state.currentSessionId, messageId: 'last', rating, note: note || undefined }),
  });
  const data = await res.json().catch(() => ({}));
  if (data.ok) {
    row.querySelector('.up').classList.toggle('voted-up', rating === 'positive');
    row.querySelector('.down').classList.toggle('voted-down', rating === 'negative');
    toast(data.preference ? `已记录反馈，并提取偏好：${data.preference}` : '已记录反馈');
    loadMemory();
  } else {
    toast('反馈失败：' + (data.message || data.error || '未知'));
  }
}

/* ---------------- 会话 ---------------- */
async function refreshSessions() {
  const state2 = await fetchJson('/api/state');
  if (!state2) return;
  const list = $('#sessionList');
  const query = $('#sessionSearch').value.toLowerCase();
  list.innerHTML = '';
  for (const s of state2.sessions) {
    const title = (s.last && s.last.text) || '新会话';
    if (query && !title.toLowerCase().includes(query) && !s.id.includes(query)) continue;
    const item = document.createElement('div');
    item.className = `session-item${s.id === state.currentSessionId ? ' active' : ''}`;
    item.innerHTML = `
      <div class="title">${escapeHtml(title.slice(0, 40))}</div>
      <div class="meta"><span>${s.messages} 条消息</span>${s.running ? '<span class="running-dot"></span>' : ''}</div>`;
    item.addEventListener('click', () => selectSession(s.id));
    list.appendChild(item);
  }
  const modelInfo = $('#modelInfo');
  if (modelInfo) modelInfo.innerHTML = `模型：<strong>${escapeHtml(state2.model.model)}</strong><br>Provider：${escapeHtml(state2.model.provider)}<br>Token 预算：${state2.config.tokenBudget}`;
}

function selectSession(id) {
  state.currentSessionId = id;
  refreshSessions();
  loadSessionMessages(id);
  toggleSidebar(false);
}

async function loadSessionMessages(id) {
  const state2 = await fetchJson('/api/state');
  const session = (state2?.sessions || []).find((s) => s.id === id);
  if (!session) return;
  const m = $('#messages');
  m.innerHTML = '';
  // 历史消息通过 state 接口返回有限信息，这里重新拉取完整历史
  const full = await fetchJson(`/api/state`);
  // 为简洁：加载历史消息内容
  const history = await fetchJson('/api/history?id=' + id);
  if (history && Array.isArray(history.messages)) {
    for (const msg of history.messages) {
      if (msg.role === 'user') addMessage('user', msg.text);
      else if (msg.role === 'assistant' && msg.text) {
        const bubble = addMessage('agent', '');
        bubble.textContent = msg.text;
        finalizeBubble(bubble, msg.text);
      }
    }
  }
  if (m.children.length === 0) {
    m.innerHTML = `<div class="empty-state"><div class="empty-icon"></div><h1>开始新的对话</h1><p>在下方输入你的第一个请求。</p></div>`;
  }
}

$('#newSession').addEventListener('click', () => {
  state.currentSessionId = null;
  $('#messages').innerHTML = '';
  const empty = document.createElement('div');
  empty.className = 'empty-state';
  empty.id = 'emptyState';
  empty.innerHTML = `<div class="empty-icon"><svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="#0071e3" stroke-width="1.5"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg></div><h1>你好，我是探路者HARNESS</h1><p>我可以规划任务、调用工具、反思修正，并记住你的偏好。试试问我点什么。</p>`;
  $('#messages').appendChild(empty);
  refreshSessions();
});

$('#sessionSearch').addEventListener('input', refreshSessions);

/* ---------------- 记忆面板（单篇文本） ---------------- */
async function loadMemory() {
  const data = await fetchJson('/api/memory');
  if (data) $('#memoryText').value = data.prompt || '';
}

$('#saveMemory').addEventListener('click', async () => {
  const text = $('#memoryText').value;
  const res = await fetch('/api/memory', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'save', text }) });
  const data = await res.json().catch(() => ({}));
  if (data.ok) { toast('记忆已保存'); loadMemory(); }
  else toast('保存失败：' + (data.error || '未知'));
});

$('#clearMemory').addEventListener('click', async () => {
  if (!confirm('确定清空整篇长期记忆？')) return;
  await fetch('/api/memory', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'clear' }) });
  $('#memoryText').value = '';
  toast('已清空记忆');
});

$('#copyMemory').addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText($('#memoryText').value);
    toast('已复制到剪贴板');
  } catch {
    $('#memoryText').select();
    document.execCommand('copy');
    toast('已复制到剪贴板');
  }
});

/* ---------------- 设置面板（供应商 + 工作区 + 模型） ---------------- */
let providersCache = [];
let settingsCache = {};

async function loadState() {
  const data = await fetchJson('/api/state');
  if (!data) return;
  providersCache = data.providers || [];
  settingsCache = data.settings || {};
  renderProviders();
  renderModelSelect();
  $('#workspace').value = settingsCache.workspace || '';
  $('#temperature').value = settingsCache.temperature ?? 0.3;
  $('#temperatureValue').textContent = settingsCache.temperature ?? 0.3;
  $('#maxTokens').value = settingsCache.maxTokens ?? 4096;
  $('#modelInfo').innerHTML = `当前模型：<strong>${escapeHtml(data.model.model)}</strong><br>Provider：${escapeHtml(data.model.provider)}<br>工作区：${escapeHtml(data.workspace || '未设置')}`;
}

function renderProviders() {
  const list = $('#providerList');
  list.innerHTML = '';
  if (providersCache.length === 0) {
    list.innerHTML = '<div style="color:#86868b;font-size:13px;padding:8px 0">未配置供应商。添加后可像 DSH 一样自定义模型接入。</div>';
    return;
  }
  for (const p of providersCache) {
    const isActive = settingsCache.providerId === p.id;
    const item = document.createElement('div');
    item.className = `provider-item${isActive ? ' active' : ''}`;
    item.innerHTML = `
      <div class="provider-row">
        <div class="provider-info">
          <div class="provider-name">${escapeHtml(p.displayName)}${isActive ? ' <span class="badge">当前</span>' : ''}</div>
          <div class="provider-meta">${escapeHtml(p.id)} · ${escapeHtml(p.baseURL)} · ${escapeHtml(p.protocol)}</div>
          <div class="provider-models">模型：${escapeHtml((p.models || []).join(', ') || '未填写')}</div>
        </div>
        <div class="provider-actions">
          ${!isActive ? `<button class="mini-btn" data-use="${p.id}">使用</button>` : ''}
          <button class="mini-btn danger" data-del="${p.id}">删除</button>
        </div>
      </div>`;
    item.querySelector(`[data-use]`)?.addEventListener('click', () => useProvider(p.id));
    item.querySelector(`[data-del]`)?.addEventListener('click', () => removeProvider(p.id));
    list.appendChild(item);
  }
}

function renderModelSelect() {
  const sel = $('#modelSelect');
  const active = providersCache.find((p) => p.id === settingsCache.providerId);
  sel.innerHTML = '';
  if (!active) {
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = '（未选择供应商）';
    sel.appendChild(opt);
    return;
  }
  const models = active.models || [];
  for (const m of models) {
    const opt = document.createElement('option');
    opt.value = m;
    opt.textContent = m;
    if (m === settingsCache.model) opt.selected = true;
    sel.appendChild(opt);
  }
  if (models.length === 0) {
    const opt = document.createElement('option');
    opt.value = settingsCache.model || '';
    opt.textContent = settingsCache.model || '（未填写模型）';
    sel.appendChild(opt);
  }
}

async function useProvider(id) {
  await fetch('/api/settings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ providerId: id }) });
  await loadState();
  toast('已切换供应商，下次对话生效');
}

async function removeProvider(id) {
  if (!confirm('删除该供应商？')) return;
  await fetch('/api/providers', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'remove', id }) });
  await loadState();
  toast('已删除');
}

$('#addProviderBtn').addEventListener('click', () => { $('#providerForm').style.display = 'block'; $('#addProviderBtn').style.display = 'none'; });
$('#cancelProvider').addEventListener('click', () => { $('#providerForm').style.display = 'none'; $('#addProviderBtn').style.display = 'block'; });

$('#saveProvider').addEventListener('click', async () => {
  const provider = {
    id: $('#pId').value.trim(),
    displayName: $('#pName').value.trim(),
    baseURL: $('#pUrl').value.trim(),
    protocol: $('#pProtocol').value,
    apiKey: $('#pKey').value.trim(),
    models: $('#pModels').value.split(',').map((s) => s.trim()).filter(Boolean),
    model: $('#pModels').value.split(',').map((s) => s.trim()).filter(Boolean)[0] || '',
  };
  if (!provider.id) { toast('Provider ID 不能为空'); return; }
  if (!provider.baseURL) { toast('API 地址不能为空'); return; }
  const res = await fetch('/api/providers', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'add', provider }) });
  const data = await res.json().catch(() => ({}));
  if (data.ok) {
    $('#pId').value = $('#pName').value = $('#pUrl').value = $('#pKey').value = $('#pModels').value = '';
    $('#providerForm').style.display = 'none';
    $('#addProviderBtn').style.display = 'block';
    await loadState();
    toast('供应商已保存' + (settingsCache.providerId === data.provider.id ? '，已设为当前' : ''));
  } else {
    toast('保存失败：' + (data.error || '未知'));
  }
});

$('#saveSettings').addEventListener('click', async () => {
  const body = {
    workspace: $('#workspace').value.trim(),
    model: $('#modelSelect').value,
    temperature: parseFloat($('#temperature').value),
    maxTokens: parseInt($('#maxTokens').value, 10),
  };
  const res = await fetch('/api/settings', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const data = await res.json().catch(() => ({}));
  if (data.ok) { toast('设置已保存'); loadState(); }
  else toast('保存失败：' + (data.error || '未知'));
});

$('#temperature').addEventListener('input', (e) => { $('#temperatureValue').textContent = e.target.value; });
$('#clearContext').addEventListener('click', () => sessionAction('/api/clear'));
$('#resetSession').addEventListener('click', () => sessionAction('/api/reset'));
async function sessionAction(url) {
  if (!state.currentSessionId) { toast('请先选择一个会话'); return; }
  const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sessionId: state.currentSessionId }) });
  const data = await res.json().catch(() => ({}));
  if (data.ok) toast(url.includes('reset') ? '会话已重置' : '上下文已清除');
}

/* ---------------- 工具函数 ---------------- */
async function fetchJson(url) {
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}
function escapeHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/* ---------------- 事件绑定 ---------------- */
const input = $('#input');
input.addEventListener('input', () => { setSendState('idle'); autoResize(); });
function autoResize() {
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, 160) + 'px';
}
input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage(input.value);
  }
});
$('#send').addEventListener('click', () => {
  if (state.streaming) {
    stopStreaming();
  } else {
    sendMessage(input.value);
  }
});
function stopStreaming() {
  if (state.abortController) {
    state.abortController.abort();
    state.abortController = null;
  }
  if (state.currentSessionId) {
    fetch('/api/stop', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sessionId: state.currentSessionId }) }).catch(() => {});
  }
  setSendState('idle');
}
document.querySelectorAll('.chip').forEach((chip) => {
  chip.addEventListener('click', () => sendMessage(chip.dataset.suggest));
});

/* ---------------- 初始化 ---------------- */
(async function init() {
  await refreshSessions();
  setSendState('idle');
  autoResize();
})();
