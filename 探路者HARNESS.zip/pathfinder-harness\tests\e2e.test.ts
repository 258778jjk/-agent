/**
 * e2e.test.ts —— 端到端集成测试
 *
 * 覆盖用户要求的完整对话流程：
 *   1. 用户询问天气 → Agent 调用天气工具 → 返回结果
 *   2. 用户要求「记住城市」→ 记忆写入并可在下次检索
 *   3. 记忆注入：长期记忆/偏好进入模型 system prompt（用 echo mock 验证）
 *   4. 流式输出接口 + 中断功能（经 HTTP SSE）
 */

import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import type { Server } from 'node:http'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { startServer } from '../src/server.ts'
import { loadAgentConfig } from '../src/config.ts'
import { runTurn } from '../src/agent.ts'
import { createTools } from '../src/tools.ts'
import { MemoryStore } from '../src/memory.ts'
import { Session } from '../src/session.ts'
import type { AgentConfig, LlmConfig } from '../src/config.ts'

let server: Server
let base: string
let root: string

before(async () => {
  root = mkdtempSync(join(tmpdir(), 'sa-e2e-'))
  const config = loadAgentConfig()
  config.persistence.dir = root
  config.server.port = 0
  server = await startServer(config, { port: 0, mock: true })
  const addr = server.address()
  base = `http://127.0.0.1:${typeof addr === 'object' && addr ? addr.port : 0}`
})

after(() => server?.close())

async function chat(message: string, sessionId?: string): Promise<{ body: string; sessionId: string }> {
  const res = await fetch(base + '/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ message, ...(sessionId ? { sessionId } : {}) }),
  })
  const body = await res.text()
  // 从 done 帧提取 sessionId（done 帧不含 sessionId，改用 state 里最新的会话）
  const state = (await (await fetch(base + '/api/state')).json()) as { sessions: Array<{ id: string }> }
  const sid = state.sessions[state.sessions.length - 1]!.id
  return { body, sessionId: sid }
}

test('E2E：询问天气 → 工具调用 → 记住城市 → 记忆可检索', async () => {
  // 1) 询问天气（触发 weather 工具）
  const first = await chat('北京今天的天气怎么样')
  assert.match(first.body, /event: done/)
  assert.match(first.body, /weather/) // 工具事件

  // 2) 记住城市
  await chat('记住我住在北京', first.sessionId)

  // 3) 记忆可检索（单篇文本）
  const mem = (await (await fetch(base + '/api/memory')).json()) as { prompt: string }
  assert.match(mem.prompt, /我住在北京/)

  // 4) 反馈 → 偏好提取
  const fb = await fetch(base + '/api/feedback', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sessionId: first.sessionId, messageId: 'last', rating: 'down', note: '以后回答更简洁' }),
  })
  const fbData = (await fb.json()) as { ok: boolean; preference?: string }
  assert.equal(fbData.ok, true)
  assert.ok(fbData.preference)

  // 5) 恢复会话（同一 sessionId 继续，上下文 + 记忆保留）
  const resume = await chat('再说一遍', first.sessionId)
  assert.match(resume.body, /event: done/)
})

test('E2E：记忆注入 —— 长期记忆进入模型 system prompt', async () => {
  const config: AgentConfig = {
    persona: '你是测试 Agent',
    llm: { provider: 'mock', model: 'mock', baseURL: '', apiKeyEnv: 'auto', maxTokens: 2048, timeoutMs: 5000, temperature: 0 },
    tools: { enabled: ['calculator'], requireApproval: [], workspaceRoot: './workspace' },
    planning: { enabled: true, maxSteps: 5, maxReplans: 1 },
    reflection: { enabled: false, maxCorrections: 0 },
    memory: { enabled: true, inject: true, maxInjectedItems: 10, shortTermTurns: 8, maxNoteBytes: 8192 },
    context: { tokenBudget: 8000, summarizeThreshold: 0.7, maxSummarizeRetries: 1 },
    persistence: { dir: root },
    server: { host: '127.0.0.1', port: 0 },
  }
  const memory = new MemoryStore(mkdtempSync(join(tmpdir(), 'sa-inj-')), { maxNoteBytes: 8192 })
  memory.addMemory('fact', '用户住在北京', 's1', 'user-explicit')
  memory.addMemory('preference', '用户喜欢简洁', 's1', 'feedback')
  const session = new Session({ version: 1, id: 's-inj', createdAt: Date.now() })
  session.append('user', [{ type: 'text', text: '你好' }], { kind: 'user' })

  // echo mock：把 system prompt 原样返回，以验证记忆确实进入模型上下文
  const echoMock = {
    complete: async (request: { system: string }) => ({
      content: 'ECHO_SYSTEM:' + request.system,
      toolCalls: [] as never[],
      finishReason: 'stop',
      usage: { inputTokens: 1, outputTokens: 1 },
    }),
  }
  const result = await runTurn({
    session,
    config,
    llm: { provider: 'mock', baseURL: '', apiKey: undefined, model: 'mock', maxTokens: 2048, timeoutMs: 5000, temperature: 0 } as LlmConfig,
    tools: createTools(config.tools.enabled, config.tools.requireApproval),
    memory,
    hooks: { onEvent: () => {}, onDelta: () => {}, askApproval: async () => true },
    mockLlm: echoMock as never,
    persist: () => {},
    workspaceRoot: tmpdir(),
  })
  assert.match(result.text, /用户住在北京/)
  assert.match(result.text, /用户喜欢简洁/)
})

test('E2E：流式输出含多个 delta 帧，且中断接口可调用', async () => {
  const { body, sessionId } = await chat('请说一段话')
  const deltaCount = (body.match(/event: delta/g) ?? []).length
  assert.ok(deltaCount >= 1)

  // 中断接口（无进行中请求时优雅返回 ok:false，不报 500）
  const stop = await fetch(base + '/api/stop', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sessionId }) })
  assert.equal(stop.status, 200)
})
