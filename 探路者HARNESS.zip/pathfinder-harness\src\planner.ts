/**
 * planner —— 任务规划（Plan-and-Execute 模式）。
 *
 * - ensurePlan：让 LLM 把用户请求分解为分步计划（JSON：{steps:[{id,title,tool,priority,status}]}）
 * - nextStep：按优先级取出下一个待执行步骤
 * - markDone / markFailed / markSkipped：动态更新计划状态
 * - replan：失败重规划（把失败上下文回喂 LLM，重新生成剩余步骤），有次数上限
 * - 计划状态变更走 onUpdate 回调（推送给前端监控）
 */

import type { WireMessage } from './llm.ts'

export type PlanStatus = 'pending' | 'running' | 'done' | 'failed' | 'skipped'

export interface PlanStep {
  id: number
  title: string
  tool?: string | null
  priority: number
  status: PlanStatus
}

export interface Plan {
  steps: PlanStep[]
  replans: number
}

export interface PlanUpdate {
  plan: Plan
  change: 'created' | 'step-status' | 'replanned'
  detail?: string
}

export interface PlannerConfig {
  enabled: boolean
  maxSteps: number
  maxReplans: number
}

export interface PlannerHooks {
  onUpdate?: (update: PlanUpdate) => void
  /** 生成计划的 LLM 调用（无工具） */
  generatePlan: (prompt: string, signal?: AbortSignal) => Promise<string>
}

export const PLAN_PROMPT = (
  task: string,
  tools: string[],
): string => `请把以下用户请求分解为可执行的分步计划，并输出 JSON（不要输出其它内容）：
{"steps":[{"id":1,"title":"步骤标题","tool":"可选，该步骤要用的工具名或 null","priority":1,"status":"pending"}]}
规则：步骤 2-8 步；priority 越小越先执行（重要步骤给更小值）；tool 只能从 [${tools.join(', ')}] 中选择，纯推理步骤用 null；不要引用任何工具参数。
用户请求：${task.slice(0, 1500)}`

export const REPLAN_PROMPT = (
  plan: Plan,
  failed: PlanStep,
  error: string,
  tools: string[],
): string => `任务执行中步骤失败，请重新规划剩余步骤并输出 JSON（不要输出其它内容）：
{"steps":[{"id":1,"title":"步骤标题","tool":"工具名或 null","priority":1,"status":"pending"}]}
已失败步骤：${failed.title}（${error.slice(0, 300)}）
剩余未完成步骤：${plan.steps.filter((s) => s.status === 'pending').map((s) => s.title).join('、') || '无'}
可用工具：[${tools.join(', ')}]`

export function parsePlan(text: string): Plan | undefined {
  const cleaned = text.replace(/```json/gi, '').replace(/```/g, '').trim()
  const start = cleaned.indexOf('{')
  const end = cleaned.lastIndexOf('}')
  if (start < 0 || end <= start) return undefined
  try {
    const parsed = JSON.parse(cleaned.slice(start, end + 1)) as { steps?: Array<Partial<PlanStep>> }
    if (!Array.isArray(parsed.steps) || parsed.steps.length === 0) return undefined
    const steps: PlanStep[] = parsed.steps
      .filter((s) => typeof s.title === 'string' && s.title.trim() !== '')
      .slice(0, 12)
      .map((s, i) => ({
        id: typeof s.id === 'number' ? s.id : i + 1,
        title: String(s.title),
        tool: typeof s.tool === 'string' && s.tool !== '' ? s.tool : null,
        priority: typeof s.priority === 'number' ? s.priority : i + 1,
        status: 'pending' as PlanStatus,
      }))
    return { steps, replans: 0 }
  } catch {
    return undefined
  }
}

export class Planner {
  private plan: Plan | undefined
  private tools: string[]
  private replanCount = 0
  private readonly cfg: PlannerConfig
  private readonly hooks: PlannerHooks

  constructor(cfg: PlannerConfig, toolNames: string[], hooks: PlannerHooks) {
    this.cfg = cfg
    this.hooks = hooks
    this.tools = toolNames
  }

  get current(): Plan | undefined {
    return this.plan
  }

  /** 生成初始计划；LLM 输出无法解析时降级为单步计划（优雅降级）。 */
  async ensurePlan(task: string, signal?: AbortSignal): Promise<Plan> {
    if (this.plan) return this.plan
    let parsed: Plan | undefined
    try {
      const raw = await this.hooks.generatePlan(PLAN_PROMPT(task, this.tools), signal)
      parsed = parsePlan(raw)
    } catch {
      parsed = undefined
    }
    if (!parsed) {
      // 优雅降级：单步计划直接执行用户请求
      parsed = { steps: [{ id: 1, title: '执行用户请求', tool: null, priority: 1, status: 'pending' }], replans: 0 }
    }
    parsed.replans = 0
    this.plan = parsed
    this.replanCount = 0
    this.hooks.onUpdate?.({ plan: structuredClone(this.plan), change: 'created' })
    return this.plan
  }

  /** 按优先级取出下一个待执行步骤。 */
  nextStep(): PlanStep | undefined {
    if (!this.plan) return undefined
    const pending = this.plan.steps.filter((s) => s.status === 'pending')
    if (pending.length === 0) return undefined
    pending.sort((a, b) => a.priority - b.priority || a.id - b.id)
    return pending[0]
  }

  /** 是否全部完成（或全部终结）。 */
  isFinished(): boolean {
    if (!this.plan) return true
    return this.plan.steps.every((s) => s.status === 'done' || s.status === 'skipped' || s.status === 'failed')
  }

  private setStatus(id: number, status: PlanStatus): void {
    if (!this.plan) return
    const step = this.plan.steps.find((s) => s.id === id)
    if (!step || step.status === status) return
    step.status = status
    this.hooks.onUpdate?.({ plan: structuredClone(this.plan), change: 'step-status', detail: `步骤 ${id}（${step.title}）→ ${status}` })
  }

  markRunning(id: number): void {
    this.setStatus(id, 'running')
  }
  markDone(id: number): void {
    this.setStatus(id, 'done')
  }
  markSkipped(id: number): void {
    this.setStatus(id, 'skipped')
  }
  markFailed(id: number): void {
    this.setStatus(id, 'failed')
  }

  /** 失败重规划：生成新计划替换剩余 pending 步骤。返回是否重规划成功。 */
  async replan(failed: PlanStep, error: string, signal?: AbortSignal): Promise<boolean> {
    if (!this.plan || !this.cfg.enabled) return false
    if (this.replanCount >= this.cfg.maxReplans) return false
    this.replanCount++
    try {
      const raw = await this.hooks.generatePlan(REPLAN_PROMPT(this.plan, failed, error, this.tools), signal)
      const parsed = parsePlan(raw)
      if (!parsed || parsed.steps.length === 0) return false
      const doneSteps = this.plan.steps.filter((s) => s.status === 'done' || s.status === 'running')
      const newSteps = parsed.steps.map((s, i) => ({ ...s, id: 100 + i, status: 'pending' as PlanStatus }))
      this.plan.steps = [...doneSteps, ...newSteps]
      this.plan.replans = this.replanCount
      this.hooks.onUpdate?.({ plan: structuredClone(this.plan), change: 'replanned', detail: `重规划：新增 ${newSteps.length} 个步骤` })
      return true
    } catch {
      return false
    }
  }

  /** 计划的模型可见文本（执行步骤时注入）。 */
  renderForModel(): string {
    if (!this.plan) return ''
    const lines = this.plan.steps.map((s) => {
      const icon = s.status === 'done' ? '✅' : s.status === 'running' ? '▶️' : s.status === 'failed' ? '❌' : s.status === 'skipped' ? '⏭️' : '⬜'
      return `${icon} [${s.id}] ${s.title}${s.tool ? ` (工具: ${s.tool})` : ''}`
    })
    return `当前计划进度：\n${lines.join('\n')}\n你正在执行其中标注 ▶️ 的步骤。`
  }
}
