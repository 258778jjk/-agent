/**
 * runtime.test.ts —— 运行时供应商注册表 + 运行设置单元测试
 * 覆盖：供应商增删查、默认供应商自动选择、工作区解析、模型选择、自定义供应商优先于 DSH/env。
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { RuntimeStore } from '../src/runtime.ts'
import { loadAgentConfig } from '../src/config.ts'

function makeStore() {
  return new RuntimeStore(mkdtempSync(join(tmpdir(), 'sa-rt-')))
}

test('供应商：添加/查询/删除', () => {
  const rt = makeStore()
  rt.addProvider({ id: 'acme', displayName: 'ACME', baseURL: 'https://gw.example/v1', protocol: 'openai-completions', apiKey: 'sk-1', models: ['m-a', 'm-b'], model: 'm-a' })
  assert.equal(rt.getProvider('acme')?.displayName, 'ACME')
  assert.equal(rt.listProviders().length, 1)
  assert.equal(rt.removeProvider('acme'), true)
  assert.equal(rt.getProvider('acme'), undefined)
  assert.equal(rt.removeProvider('acme'), false)
})

test('供应商：id 统一小写，重复 id 为更新', () => {
  const rt = makeStore()
  rt.addProvider({ id: 'Acme', displayName: 'A', baseURL: 'https://a', protocol: 'x', apiKey: '', models: [], model: '' })
  assert.equal(rt.getProvider('acme')?.displayName, 'A')
  rt.addProvider({ id: 'ACME', displayName: 'B', baseURL: 'https://b', protocol: 'x', apiKey: '', models: [], model: '' })
  assert.equal(rt.listProviders().length, 1)
  assert.equal(rt.getProvider('acme')?.displayName, 'B')
})

test('运行设置：默认值 + 读写', () => {
  const rt = makeStore()
  const s = rt.loadSettings()
  assert.equal(s.workspace, '')
  assert.equal(s.providerId, '')
  assert.equal(s.temperature, 0.3)
  rt.saveSettings({ ...s, workspace: 'D:/ws', temperature: 0.9, maxTokens: 2048 })
  assert.equal(rt.loadSettings().temperature, 0.9)
  assert.equal(rt.loadSettings().maxTokens, 2048)
})

test('工作区：设置后解析为绝对路径，为空回退 config', () => {
  const rt = makeStore()
  const fallback = resolve('./workspace')
  assert.equal(rt.resolveWorkspace(fallback), fallback)
  rt.saveSettings({ ...rt.loadSettings(), workspace: 'D:/my/work' })
  assert.equal(rt.resolveWorkspace(fallback), resolve('D:/my/work'))
})

test('模型选择：设置 model > 供应商默认 > 目录第一个', () => {
  const rt = makeStore()
  rt.addProvider({ id: 'p', displayName: 'P', baseURL: 'https://x', protocol: 'x', apiKey: '', models: ['m-1', 'm-2'], model: 'm-2' })
  rt.saveSettings({ ...rt.loadSettings(), providerId: 'p' })
  assert.equal(rt.activeModel(), 'm-2') // 供应商默认
  rt.saveSettings({ ...rt.loadSettings(), model: 'm-3' })
  assert.equal(rt.activeModel(), 'm-3') // 设置覆盖
})

test('resolveLlm：自定义供应商优先（覆盖 DSH/env 解析）', () => {
  const rt = makeStore()
  const cfg = loadAgentConfig()
  rt.addProvider({ id: 'acme', displayName: 'ACME', baseURL: 'https://gw.example/v1/', protocol: 'openai-completions', apiKey: 'sk-custom', models: ['m-a'], model: 'm-a' })
  rt.saveSettings({ ...rt.loadSettings(), providerId: 'acme', model: 'm-a', maxTokens: 3000, temperature: 0.5 })
  const llm = rt.resolveLlm(cfg, false)
  assert.equal(llm.provider, 'acme')
  assert.equal(llm.baseURL, 'https://gw.example/v1') // 去尾斜杠
  assert.equal(llm.apiKey, 'sk-custom')
  assert.equal(llm.model, 'm-a')
  assert.equal(llm.maxTokens, 3000)
  assert.equal(llm.temperature, 0.5)
})

test('resolveLlm：无供应商时回退（不抛异常）', () => {
  const rt = makeStore()
  const llm = rt.resolveLlm(loadAgentConfig(), false)
  assert.equal(typeof llm.provider, 'string')
  assert.equal(typeof llm.model, 'string')
})

test('resolveLlm：mock 优先返回 mock 配置', () => {
  const rt = makeStore()
  const llm = rt.resolveLlm(loadAgentConfig(), true)
  assert.equal(llm.provider, 'mock')
  assert.equal(llm.model, 'mock-model')
})
