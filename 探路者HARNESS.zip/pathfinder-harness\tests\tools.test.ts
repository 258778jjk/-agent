/**
 * tools.test.ts —— 工具系统单元测试
 * 覆盖：计算器、天气、模拟数据库、文件读写、权限审批、并行聚合、异常归一化。
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, mkdirSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { createTools, executeCalls } from '../src/tools.ts'

function makeRegistry() {
  return createTools(['calculator', 'web_search', 'weather', 'file_read', 'file_write', 'db_query'], ['file_write'])
}

test('calculator：正确计算算术表达式', async () => {
  const reg = makeRegistry()
  const r = await reg.execute('calculator', { expression: '(123*45+678)/3' }, { workspaceRoot: tmpdir() })
  assert.equal(r.ok, true)
  assert.match(r.output, /2071/)
})

test('calculator：拒绝非法表达式', async () => {
  const reg = makeRegistry()
  const r = await reg.execute('calculator', { expression: 'process.exit()' }, { workspaceRoot: tmpdir() })
  assert.equal(r.ok, false)
  assert.match(r.output, /不支持/)
})

test('weather：同城同日结果稳定', async () => {
  const reg = makeRegistry()
  const a = await reg.execute('weather', { city: '北京' }, { workspaceRoot: tmpdir() })
  const b = await reg.execute('weather', { city: '北京' }, { workspaceRoot: tmpdir() })
  assert.equal(a.ok, true)
  assert.equal(a.output, b.output)
  assert.match(a.output, /北京/)
})

test('db_query：SELECT 查询与 WHERE 过滤', async () => {
  const reg = makeRegistry()
  const all = await reg.execute('db_query', { sql: 'SELECT * FROM users' }, { workspaceRoot: tmpdir() })
  const filtered = await reg.execute('db_query', { sql: "SELECT name FROM users WHERE city='北京'" }, { workspaceRoot: tmpdir() })
  assert.equal(all.ok, true)
  assert.match(all.output, /张三/)
  assert.equal(filtered.ok, true)
  assert.match(filtered.output, /张三/)
  assert.doesNotMatch(filtered.output, /李四/)
})

test('file_read：读取带行号窗口', async () => {
  const root = mkdtempSync(join(tmpdir(), 'sa-fs-'))
  writeFileSync(join(root, 'a.txt'), 'l1\nl2\nl3\nl4\n')
  const reg = makeRegistry()
  const r = await reg.execute('file_read', { path: 'a.txt', offset: 2, limit: 2 }, { workspaceRoot: root })
  assert.equal(r.ok, true)
  assert.match(r.output, /2: l2/)
  assert.match(r.output, /3: l3/)
})

test('file_read：阻止路径越界', async () => {
  const root = mkdtempSync(join(tmpdir(), 'sa-fs2-'))
  const reg = makeRegistry()
  const r = await reg.execute('file_read', { path: '../../etc/passwd' }, { workspaceRoot: root })
  assert.equal(r.ok, false)
  assert.match(r.output, /越界/)
})

test('file_write：需要审批，拒绝时不执行', async () => {
  const root = mkdtempSync(join(tmpdir(), 'sa-fs3-'))
  const reg = makeRegistry()
  const results = await executeCalls(reg, [{ id: 'c1', name: 'file_write', arguments: '{"path":"x.txt","content":"hi"}' }], { workspaceRoot: root }, async () => false)
  assert.equal(results[0]!.result.denied, true)
  assert.equal(results[0]!.result.ok, false)
})

test('file_write：审批通过后原子写入', async () => {
  const root = mkdtempSync(join(tmpdir(), 'sa-fs4-'))
  mkdirSync(root, { recursive: true })
  const reg = makeRegistry()
  const results = await executeCalls(reg, [{ id: 'c1', name: 'file_write', arguments: '{"path":"y.txt","content":"hello"}' }], { workspaceRoot: root }, async () => true)
  assert.equal(results[0]!.result.ok, true)
  const readBack = await reg.execute('file_read', { path: 'y.txt' }, { workspaceRoot: root })
  assert.match(readBack.output, /hello/)
})

test('并行执行：多个工具结果全部聚合', async () => {
  const reg = makeRegistry()
  const results = await executeCalls(
    reg,
    [
      { id: 'a', name: 'calculator', arguments: '{"expression":"1+1"}' },
      { id: 'b', name: 'weather', arguments: '{"city":"上海"}' },
    ],
    { workspaceRoot: tmpdir() },
    async () => true,
  )
  assert.equal(results.length, 2)
  assert.ok(results.every((r) => r.result.ok))
  assert.equal(new Set(results.map((r) => r.callId)).size, 2)
})

test('未知工具：返回统一错误而非抛异常', async () => {
  const reg = makeRegistry()
  const r = await reg.execute('nonexistent', {}, { workspaceRoot: tmpdir() })
  assert.equal(r.ok, false)
  assert.match(r.output, /unknown tool/)
})
