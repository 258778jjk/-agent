/**
 * server.test.ts —— HTTP/SSE 集成测试
 * 覆盖：静态页、/api/state、/api/chat SSE 流式、/api/feedback、/api/memory 编辑、/api/stop、/api/clear。
 */

import { test, before, after } from 'node:test'
import assert from 'node:assert/strict'
import type { Server } from 'node:http'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { startServer } from '../src/server.ts'
import { loadAgentConfig } from '../src/config.ts'

let server: Server
let base: string

before(async () => {
  const root = mkdtempSync(join(tmpdir(), 'sa-server-'))
  const config = loadAgentConfig()
  config.persistence.dir = root
  config.server.port = 0
  server = await startServer(config, { port: 0, mock: true })
  const addr = server.address()
  const port = typeof addr === 'object' && addr ? addr.port : 0
  base = `http://127.0.0.1:${port}`
})

after(() => {
  server?.close()
})

async function post(path: string, body: unknown): Promise<Response> {
  return fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
}

async function getJson(path: string): Promise<Record<string, unknown>> {
  return (await (await fetch(base + path)).json()) as Record<string, unknown>
}

test('GET / 返回控制台 HTML', async () => {
  const res = await fetch(base + '/')
  assert.equal(res.status, 200)
  assert.match(res.headers.get('content-type') ?? '', /text\/html/)
  const html = await res.text()
  assert.match(html, /探路者HARNESS/)
})

test('GET /api/state 返回记忆文本与结构', async () => {
  const data = await getJson('/api/state')
  assert.ok(Array.isArray(data.sessions))
  assert.ok(data.memory)
  assert.equal(typeof (data.memory as { prompt: string }).prompt, 'string')
  assert.equal(typeof (data.model as { model: string }).model, 'string')
})

test('POST /api/chat 返回 SSE 流式响应（delta + done）', async () => {
  const res = await post('/api/chat', { message: '帮我算一下 1+2' })
  assert.equal(res.status, 200)
  assert.match(res.headers.get('content-type') ?? '', /text\/event-stream/)
  const body = await res.text()
  assert.match(body, /event: done/)
  const doneFrame = body.split('\n\n').find((f) => f.startsWith('event: done'))
  assert.ok(doneFrame)
  const doneData = JSON.parse(doneFrame.split('\ndata: ')[1]!)
  assert.equal(typeof doneData.text, 'string')
  assert.ok(doneData.text.length > 0)
})

test('流式输出：存在 delta 事件', async () => {
  const res = await post('/api/chat', { message: '你好' })
  const body = await res.text()
  assert.match(body, /event: delta/)
})

test('POST /api/feedback 记录反馈并提取偏好', async () => {
  // 先产生一条助手消息
  const chat = await post('/api/chat', { message: '记住我喜欢简洁' })
  await chat.text()
  const state = await getJson('/api/state')
  const sessions = state.sessions as Array<{ id: string }>
  const sid = sessions[0]!.id
  const res = await post('/api/feedback', { sessionId: sid, messageId: 'last', rating: 'down', note: '以后请更简洁' })
  const data = (await res.json()) as Record<string, unknown>
  assert.equal(data.ok, true)
  assert.ok(data.preference)
})

test('POST /api/memory 保存与清空单篇记忆', async () => {
  const add = await post('/api/memory', { action: 'save', text: '- [事实] 测试记忆条目\n- [用户偏好] 简洁' })
  const addData = (await add.json()) as { ok: boolean; prompt: string }
  assert.equal(addData.ok, true)
  const list = await getJson('/api/memory')
  assert.match((list.prompt as string), /测试记忆条目/)
  const clear = await post('/api/memory', { action: 'clear' })
  const clearData = (await clear.json()) as { ok: boolean }
  assert.equal(clearData.ok, true)
  const after = await getJson('/api/memory')
  assert.equal((after.prompt as string).trim(), '')
})

test('POST /api/stop 无进行中请求时优雅返回', async () => {
  const res = await post('/api/stop', { sessionId: 'nonexistent' })
  const data = (await res.json()) as { ok: boolean }
  assert.equal(data.ok, false)
})

test('POST /api/providers 添加供应商并自动设为当前', async () => {
  const res = await post('/api/providers', {
    action: 'add',
    provider: { id: 'acme', displayName: 'ACME', baseURL: 'https://gateway.example/v1', protocol: 'openai-completions', apiKey: 'sk-test-1234', models: ['m-a', 'm-b'], model: 'm-a' },
  })
  const data = (await res.json()) as { ok: boolean; provider: { id: string; apiKey: string } }
  assert.equal(data.ok, true)
  assert.equal(data.provider.id, 'acme')
  assert.match(data.provider.apiKey, /••••1234/) // 密钥脱敏返回
  const list = await getJson('/api/providers')
  const providers = list.providers as Array<{ id: string }>
  assert.ok(providers.some((p) => p.id === 'acme'))
  const settings = list.settings as { providerId: string }
  assert.equal(settings.providerId, 'acme') // 首次添加自动设为当前
})

test('POST /api/settings 保存工作区/模型/温度/Token', async () => {
  const res = await post('/api/settings', { workspace: 'D:/work/agent-ws', model: 'm-b', temperature: 0.7, maxTokens: 8192 })
  const data = (await res.json()) as { ok: boolean; settings: Record<string, unknown> }
  assert.equal(data.ok, true)
  assert.equal(data.settings.workspace, 'D:/work/agent-ws')
  assert.equal(data.settings.model, 'm-b')
  assert.equal(data.settings.temperature, 0.7)
  assert.equal(data.settings.maxTokens, 8192)
  // 回读确认持久化
  const list = await getJson('/api/providers')
  assert.equal((list.settings as { workspace: string }).workspace, 'D:/work/agent-ws')
})

test('POST /api/providers 删除供应商并清空默认引用', async () => {
  await post('/api/providers', {
    action: 'add',
    provider: { id: 'temp-prov', displayName: 'T', baseURL: 'https://x.example/v1', protocol: 'openai-completions', apiKey: '', models: [], model: '' },
  })
  const del = await post('/api/providers', { action: 'remove', id: 'temp-prov' })
  const delData = (await del.json()) as { ok: boolean; removed: boolean }
  assert.equal(delData.ok, true)
  assert.equal(delData.removed, true)
  const list = await getJson('/api/providers')
  const providers = list.providers as Array<{ id: string }>
  assert.ok(!providers.some((p) => p.id === 'temp-prov'))
})

test('POST /api/clear 清除会话上下文', async () => {
  const chat = await post('/api/chat', { message: '第一句' })
  await chat.text()
  const state = await getJson('/api/state')
  const sessions = state.sessions as Array<{ id: string }>
  const sid = sessions[0]!.id
  const res = await post('/api/clear', { sessionId: sid })
  const data = (await res.json()) as { ok: boolean }
  assert.equal(data.ok, true)
})
