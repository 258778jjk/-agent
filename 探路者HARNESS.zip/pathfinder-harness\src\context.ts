/**
 * context —— 上下文管理（对应 DSH: dsh-compaction-basic 的最简版）。
 *
 * - estimateTokens：CJK 字符 ≈1 token/字，其它 ≈4 字符/token（DeepSeek 混合计数近似）
 * - estimateSessionTokens：估算整条会话的 token 数
 * - maybeSummarize：超预算时把最早的消息区间压缩成一条 <context-summary> 消息
 *   （摘要失败时优雅降级为截断），保留最近的对话
 */

import { Session, type Message } from './session.ts'

/** 估算文本 token 数。 */
export function estimateTokens(text: string): number {
  let cjk = 0
  let other = 0
  for (const ch of text) {
    const code = ch.codePointAt(0) ?? 0
    if ((code >= 0x4e00 && code <= 0x9fff) || (code >= 0x3000 && code <= 0x303f) || (code >= 0xff00 && code <= 0xffef)) cjk++
    else other++
  }
  return cjk + Math.ceil(other / 4)
}

/** 估算会话总 token（含消息结构开销）。 */
export function estimateSessionTokens(session: Session, systemPrompt = ''): number {
  let total = estimateTokens(systemPrompt) + 32
  for (const msg of session.messages) {
    const text = msg.content.map((b) => (b.type === 'text' ? b.text : b.type === 'tool-result' ? b.content : `${b.type}:${b.name ?? ''}`)).join(' ')
    total += estimateTokens(text) + 8
  }
  return total
}

export interface ContextBudget {
  tokenBudget: number
  /** 超过预算该比例时触发摘要 */
  summarizeThreshold: number
}

export interface SummarizeResult {
  summarized: boolean
  summaryTokens: number
  currentTokens: number
}

/**
 * 超预算时自动摘要：把最老的消息（不含最近 keepRecent 条）替换为一条摘要消息。
 * 摘要失败（summarizer 抛错/返回空）→ 优雅降级为直接截断。
 */
export async function maybeSummarize(
  session: Session,
  budget: ContextBudget,
  systemPrompt: string,
  summarizer: (messages: Message[]) => Promise<string>,
  keepRecent = 6,
): Promise<SummarizeResult> {
  const current = estimateSessionTokens(session, systemPrompt)
  if (current <= budget.tokenBudget * budget.summarizeThreshold) {
    return { summarized: false, summaryTokens: 0, currentTokens: current }
  }
  const total = session.messages.length
  const keep = Math.max(2, Math.min(keepRecent, total))
  const oldMessages = session.messages.slice(0, total - keep)
  if (oldMessages.length === 0) return { summarized: false, summaryTokens: 0, currentTokens: current }

  let summary = ''
  try {
    summary = (await summarizer(oldMessages)).trim()
  } catch {
    summary = ''
  }
  if (summary === '') {
    // 优雅降级：截断最老的一半
    const drop = Math.floor(oldMessages.length / 2) + 1
    const recent = session.messages.slice(drop)
    session.messages.length = 0
    for (const m of recent) session.messages.push(m)
    const after = estimateSessionTokens(session, systemPrompt)
    return { summarized: true, summaryTokens: 0, currentTokens: after }
  }

  const summaryMsg: Message = {
    id: `summary-${Date.now()}`,
    seq: -1,
    role: 'user',
    content: [{ type: 'text', text: `<context-summary>\n${summary}\n</context-summary>` }],
    createdAt: Date.now(),
    source: { kind: 'context-summary' },
  }
  const recent = session.messages.slice(total - keep)
  session.messages.length = 0
  session.messages.push(summaryMsg, ...recent)
  return { summarized: true, summaryTokens: estimateTokens(summary), currentTokens: estimateSessionTokens(session, systemPrompt) }
}

/** 摘要提示词（要求保留关键信息 + 用户偏好）。 */
export function summarizeInstruction(messages: Message[]): string {
  const text = messages
    .map((m) => {
      const body = m.content.map((b) => (b.type === 'text' ? b.text : b.type === 'tool-result' ? `[工具结果] ${b.content.slice(0, 200)}` : `[${b.type}] ${b.name}`)).join(' ')
      return `${m.role}: ${body.slice(0, 800)}`
    })
    .join('\n')
  return (
    '请把以下对话历史压缩成一段简洁的中文摘要，保留：用户的核心请求、关键事实与数据、用户的偏好/纠正/反馈、未完成的事项。\n\n' +
    `对话历史:\n${text.slice(-6000)}`
  )
}
