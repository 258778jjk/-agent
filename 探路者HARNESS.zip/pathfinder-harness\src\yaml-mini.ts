/**
 * yaml-mini —— 极简 YAML 子集解析器（零依赖）。
 * 支持：块状映射/序列、映射序列、引号字符串、数字/布尔/null、注释、多行块标量（| >）。
 * 不支持：流式样式、锚点、别名、多文档。需要完整 YAML 时替换为 js-yaml。
 */

export type YamlValue = string | number | boolean | null | YamlValue[] | { [key: string]: YamlValue }

import { readFileSync } from 'node:fs'

interface Line {
  indent: number
  text: string
}

function tokenize(input: string): Line[] {
  const lines: Line[] = []
  for (const raw of input.split(/\r?\n/)) {
    const text = raw.replace(/\t/g, '  ')
    if (text.trim() === '') continue
    if (text.trim().startsWith('#')) continue
    const indent = text.match(/^ */)?.[0].length ?? 0
    lines.push({ indent, text: text.trim() })
  }
  return lines
}

function stripComment(text: string): string {
  let inSingle = false
  let inDouble = false
  for (let i = 0; i < text.length; i++) {
    const c = text[i]
    if (c === "'" && !inDouble) inSingle = !inSingle
    else if (c === '"' && !inSingle) inDouble = !inDouble
    else if (c === '#' && !inSingle && !inDouble) return text.slice(0, i).trimEnd()
  }
  return text.trimEnd()
}

function parseScalar(raw: string): YamlValue {
  const text = stripComment(raw).trim()
  if (text === '') return ''
  if (text === 'null' || text === '~') return null
  if (text === 'true') return true
  if (text === 'false') return false
  if (/^-?\d+$/.test(text)) return Number.parseInt(text, 10)
  if (/^-?\d+\.\d+$/.test(text)) return Number.parseFloat(text)
  if (text.startsWith('"')) {
    const inner = text.slice(1)
    if (inner.endsWith('"')) {
      return inner
        .slice(0, -1)
        .replace(/\\n/g, '\n')
        .replace(/\\t/g, '\t')
        .replace(/\\"/g, '"')
        .replace(/\\\\/g, '\\')
    }
    return inner
  }
  if (text.startsWith("'")) {
    if (text.endsWith("'")) return text.slice(1, -1).replace(/''/g, "'")
    return text.slice(1)
  }
  return text
}

function parseBlock(lines: Line[], index: number, indent: number): { value: YamlValue; next: number } {
  if (index >= lines.length) return { value: {}, next: index }
  const line = lines[index]!

  // 序列块
  if (line.text.startsWith('- ') || line.text === '-') {
    const items: YamlValue[] = []
    while (index < lines.length && lines[index]!.indent === indent && (lines[index]!.text.startsWith('- ') || lines[index]!.text === '-')) {
      const current = lines[index]!
      const rest = current.text === '-' ? '' : current.text.slice(2).trim()
      if (rest === '') {
        if (index + 1 < lines.length && lines[index + 1]!.indent > indent) {
          const child = parseBlock(lines, index + 1, lines[index + 1]!.indent)
          items.push(child.value)
          index = child.next
        } else {
          items.push(null)
          index++
        }
      } else if (rest.includes(':')) {
        const obj: { [key: string]: YamlValue } = {}
        const firstKey = rest.slice(0, rest.indexOf(':')).trim()
        const firstVal = rest.slice(rest.indexOf(':') + 1).trim()
        obj[firstKey] = firstVal === '' ? {} : parseScalar(firstVal)
        index++
        while (index < lines.length && lines[index]!.indent > indent && !lines[index]!.text.startsWith('- ')) {
          const sub = lines[index]!
          const colon = sub.text.indexOf(':')
          if (colon < 0) break
          const key = sub.text.slice(0, colon).trim()
          const val = sub.text.slice(colon + 1).trim()
          if (val === '') {
            if (index + 1 < lines.length && lines[index + 1]!.indent > sub.indent) {
              const child = parseBlock(lines, index + 1, lines[index + 1]!.indent)
              obj[key] = child.value
              index = child.next
            } else {
              obj[key] = {}
              index++
            }
          } else {
            obj[key] = parseScalar(val)
            index++
          }
        }
        items.push(obj)
      } else {
        items.push(parseScalar(rest))
        index++
      }
    }
    return { value: items, next: index }
  }

  // 映射块
  const obj: { [key: string]: YamlValue } = {}
  while (index < lines.length && lines[index]!.indent === indent && !lines[index]!.text.startsWith('- ')) {
    const current = lines[index]!
    const colon = current.text.indexOf(':')
    if (colon < 0) {
      index++
      continue
    }
    const key = current.text.slice(0, colon).trim()
    const rest = current.text.slice(colon + 1).trim()

    if (rest === '|' || rest === '|-' || rest === '>' || rest === '>-') {
      const literal = rest.startsWith('>')
      const chunks: string[] = []
      index++
      while (index < lines.length && lines[index]!.indent > indent) {
        chunks.push(lines[index]!.indent === indent + 2 ? lines[index]!.text : ' '.repeat(lines[index]!.indent - indent - 2) + lines[index]!.text)
        index++
      }
      obj[key] = literal ? chunks.join(' ') + (rest.endsWith('-') ? '' : '\n') : chunks.join('\n') + (rest.endsWith('-') ? '' : '\n')
    } else if (rest === '') {
      if (index + 1 < lines.length && lines[index + 1]!.indent > indent) {
        const child = parseBlock(lines, index + 1, lines[index + 1]!.indent)
        obj[key] = child.value
        index = child.next
      } else {
        obj[key] = {}
        index++
      }
    } else {
      obj[key] = parseScalar(rest)
      index++
    }
  }
  return { value: obj, next: index }
}

/** 解析 YAML 文档，顶层必须是映射。 */
export function parseYaml(input: string): { [key: string]: YamlValue } {
  const lines = tokenize(input)
  if (lines.length === 0) return {}
  const root = parseBlock(lines, 0, lines[0]!.indent)
  return root.value as { [key: string]: YamlValue }
}

/** 读取并解析 YAML 文件；不存在或失败返回 null。 */
export function parseYamlFile(path: string): { [key: string]: YamlValue } | null {
  try {
    return parseYaml(readFileSync(path, 'utf8'))
  } catch {
    return null
  }
}
