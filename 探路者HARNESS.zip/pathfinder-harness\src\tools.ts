/**
 * tools —— 工具系统（对应 DSH: dsh-tools 注册表 + 各 dsh-tool-*）。
 *
 * 内置 6 个工具：calculator / web_search / weather / file_read / file_write / db_query。
 * - JSON Schema 定义，模型可见白名单 = {name, description, parameters}
 * - 并行执行：executeCalls 用 Promise.all 聚合
 * - 权限控制：schema.requiresApproval 的工具执行前必须经 askApproval 回调确认
 */

import { readFileSync, writeFileSync, mkdirSync, renameSync, readdirSync, statSync } from 'node:fs'
import { join, resolve, dirname, relative } from 'node:path'
import type { ToolSchema } from './llm.ts'

export interface ToolContext {
  /** 会话工作区（文件工具根） */
  workspaceRoot: string
}

export interface ToolResult {
  ok: boolean
  output: string
  /** 是否被用户拒绝 */
  denied?: boolean
}

export interface Tool {
  schema: ToolSchema & { requiresApproval?: boolean }
  run(args: Record<string, unknown>, ctx: ToolContext): Promise<ToolResult>
}

export class ToolRegistry {
  private readonly tools = new Map<string, Tool>()

  register(tool: Tool): void {
    if (this.tools.has(tool.schema.name)) throw new Error(`tool ${tool.schema.name} 已注册`)
    this.tools.set(tool.schema.name, tool)
  }

  get(name: string): Tool | undefined {
    return this.tools.get(name)
  }

  schemas(): ToolSchema[] {
    return [...this.tools.values()].map((t) => ({ name: t.schema.name, description: t.schema.description, parameters: t.schema.parameters }))
  }

  requiresApproval(name: string): boolean {
    return this.tools.get(name)?.schema.requiresApproval === true
  }

  async execute(name: string, args: Record<string, unknown>, ctx: ToolContext): Promise<ToolResult> {
    const tool = this.tools.get(name)
    if (!tool) return { ok: false, output: `unknown tool: ${name}` }
    try {
      return await tool.run(args, ctx)
    } catch (error) {
      return { ok: false, output: error instanceof Error ? error.message : String(error) }
    }
  }
}

function toStr(args: Record<string, unknown>, key: string, fallback = ''): string {
  const v = args[key]
  return typeof v === 'string' ? v : fallback
}

/* ---------------- calculator ---------------- */

/** 安全算术表达式求值：仅允许数字、空白、+ - * / % ( ) . 和幂 ^。 */
const SAFE_EXPR = /^[\d\s+\-*/%().^]+$/

function safeEval(expression: string): number {
  const expr = expression.replace(/\^/g, '**')
  if (!SAFE_EXPR.test(expr) || expr.trim() === '') throw new Error(`不支持的表达式: ${expression}`)
  // Function 沙箱式求值：表达式已通过白名单正则，只含算术符号
  const value = new Function(`"use strict"; return (${expr});`)() as unknown
  if (typeof value !== 'number' || !Number.isFinite(value)) throw new Error('表达式求值结果不是有限数字')
  return value
}

/* ---------------- web_search（模拟） ---------------- */

const KNOWLEDGE_BASE: Array<{ keys: string[]; answer: string }> = [
  { keys: ['智能体', 'agent'], answer: '智能体（Agent）是能感知环境、自主规划并执行动作的 AI 系统，核心循环为 感知-规划-行动-观察。' },
  { keys: ['大语言模型', 'llm', '大模型'], answer: '大语言模型（LLM）是基于 Transformer 架构的大规模语言模型，通过海量文本预训练获得通用语言能力。' },
  { keys: ['反馈记忆', '记忆'], answer: '反馈记忆系统通过收集用户对回复的点赞/点踩/评语，提取用户偏好并注入后续对话，使 Agent 行为持续优化。' },
  { keys: ['plan and execute', '规划'], answer: 'Plan-and-Execute 模式先让模型生成分步计划，再逐步执行，支持失败重规划与优先级排序。' },
]

/* ---------------- weather（模拟） ---------------- */

/** 确定性伪随机（按城市+日期哈希），保证同一天同城市结果稳定。 */
function hashString(s: string): number {
  let h = 2166136261
  for (const ch of s) {
    h ^= ch.codePointAt(0) ?? 0
    h = Math.imul(h, 16777619)
  }
  return h >>> 0
}

/* ---------------- db_query（模拟数据库） ---------------- */

const DB_TABLES: Record<string, Array<Record<string, unknown>>> = {
  users: [
    { id: 1, name: '张三', age: 28, city: '北京' },
    { id: 2, name: '李四', age: 34, city: '上海' },
    { id: 3, name: '王五', age: 41, city: '深圳' },
  ],
  products: [
    { id: 101, name: '机械键盘', price: 399, stock: 120 },
    { id: 102, name: '显示器', price: 1599, stock: 45 },
    { id: 103, name: '降噪耳机', price: 899, stock: 0 },
  ],
  orders: [
    { id: 1001, user_id: 1, product_id: 101, amount: 399, status: 'paid' },
    { id: 1002, user_id: 2, product_id: 102, amount: 1599, status: 'pending' },
    { id: 1003, user_id: 1, product_id: 103, amount: 899, status: 'paid' },
  ],
}

/** 极简 SQL 子集：SELECT ... FROM <table> [WHERE key = value] [LIMIT n]。 */
function fakeQuery(sql: string): string {
  const s = sql.trim().replace(/;$/, '')
  const selectMatch = /^select\s+(.+?)\s+from\s+([a-z_]+)\s*(?:where\s+(.+?))?(?:\s+limit\s+(\d+))?\s*$/i.exec(s)
  if (!selectMatch) throw new Error(`不支持的 SQL（仅支持 SELECT ... FROM <table> [WHERE k=v] [LIMIT n]）: ${sql}`)
  const [, colsRaw, table, whereRaw, limitRaw] = selectMatch
  const rows = DB_TABLES[table]
  if (!rows) throw new Error(`表不存在: ${table}（可用表: ${Object.keys(DB_TABLES).join(', ')}）`)
  let filtered = rows
  if (whereRaw) {
    const wm = /([a-z_]+)\s*=\s*['"]?([^'"\s]+)['"]?/i.exec(whereRaw)
    if (!wm) throw new Error(`不支持的 WHERE 条件: ${whereRaw}`)
    const [, key, value] = wm
    filtered = rows.filter((r) => String(r[key]) === value)
  }
  const limit = limitRaw ? Math.min(Number.parseInt(limitRaw, 10), 100) : 100
  const cols = colsRaw.trim() === '*' ? Object.keys(rows[0] ?? {}) : colsRaw.split(',').map((c) => c.trim())
  const header = cols.join(' | ')
  const body = filtered
    .slice(0, limit)
    .map((r) => cols.map((c) => String(r[c] ?? '')).join(' | '))
    .join('\n')
  return `${header}\n${body || '(0 rows)'}`
}

/* ---------------- 组装 ---------------- */

function makeCalculator(): Tool {
  return {
    schema: {
      name: 'calculator',
      description: '计算算术表达式。支持 + - * / % ( ) 与 ^（幂）。用于数学计算任务。',
      parameters: {
        type: 'object',
        properties: { expression: { type: 'string', description: '算术表达式，如 "(123*45+678)/2"' } },
        required: ['expression'],
      },
    },
    async run(args) {
      const expression = toStr(args, 'expression')
      const value = safeEval(expression)
      return { ok: true, output: `${expression} = ${value}` }
    },
  }
}

function makeWebSearch(): Tool {
  return {
    schema: {
      name: 'web_search',
      description: '搜索知识（模拟实现：内置小型知识库）。返回相关条目；找不到时返回提示。',
      parameters: {
        type: 'object',
        properties: { query: { type: 'string', description: '搜索关键词，如 "大语言模型"' } },
        required: ['query'],
      },
    },
    async run(args) {
      const query = toStr(args, 'query').toLowerCase()
      const hits = KNOWLEDGE_BASE.filter((e) => e.keys.some((k) => query.includes(k)))
      if (hits.length === 0) return { ok: true, output: `[simulated] 未找到与「${query}」相关的内置条目（示例搜索词：智能体、大语言模型、反馈记忆）` }
      return { ok: true, output: hits.map((h) => `[simulated] ${h.answer}`).join('\n') }
    },
  }
}

function makeWeather(): Tool {
  return {
    schema: {
      name: 'weather',
      description: '查询城市天气（模拟实现：确定性伪随机数据，同城同日结果稳定）。',
      parameters: {
        type: 'object',
        properties: { city: { type: 'string', description: '城市名，如 "北京"' } },
        required: ['city'],
      },
    },
    async run(args) {
      const city = toStr(args, 'city') || '未知城市'
      const today = new Date().toISOString().slice(0, 10)
      const seed = hashString(`${city}-${today}`)
      const temp = 8 + (seed % 25)
      const conditions = ['晴', '多云', '小雨', '阴', '晴间多云']
      const condition = conditions[seed % conditions.length]
      const humidity = 30 + (seed % 50)
      return { ok: true, output: `[simulated] ${city} ${today}：${condition}，气温 ${temp}°C，湿度 ${humidity}%` }
    },
  }
}

function makeFileRead(): Tool {
  return {
    schema: {
      name: 'file_read',
      description: '读取工作区内的文本文件（行号窗口）。路径相对于工作区根目录。',
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: '相对路径' },
          offset: { type: 'integer', description: '起始行（1 开始），默认 1' },
          limit: { type: 'integer', description: '最多行数，默认 2000' },
        },
        required: ['path'],
      },
    },
    async run(args, ctx) {
      const rel = toStr(args, 'path')
      const path = resolve(join(ctx.workspaceRoot, rel))
      const rootPrefix = resolve(ctx.workspaceRoot)
      if (!path.startsWith(rootPrefix)) return { ok: false, output: `路径越界：仅允许访问工作区 ${rootPrefix}` }
      const offset = Math.max(1, Number(args.offset ?? 1))
      const limit = Math.max(1, Number(args.limit ?? 2000))
      const lines = readFileSync(path, 'utf8').split(/\r?\n/)
      const slice = lines.slice(offset - 1, offset - 1 + limit)
      const numbered = slice.map((line, i) => `${String(offset + i).padStart(5)}: ${line}`).join('\n')
      return { ok: true, output: `(${rel} — 共 ${lines.length} 行，显示 ${offset}..${offset + slice.length - 1})\n${numbered}` }
    },
  }
}

function makeFileWrite(): Tool {
  return {
    schema: {
      name: 'file_write',
      description: '写文本文件到工作区（原子写，覆盖已有内容）。需要用户确认。',
      requiresApproval: true,
      parameters: {
        type: 'object',
        properties: {
          path: { type: 'string', description: '相对路径' },
          content: { type: 'string', description: '文件内容' },
        },
        required: ['path', 'content'],
      },
    },
    async run(args, ctx) {
      const rel = toStr(args, 'path')
      const path = resolve(join(ctx.workspaceRoot, rel))
      const rootPrefix = resolve(ctx.workspaceRoot)
      if (!path.startsWith(rootPrefix)) return { ok: false, output: `路径越界：仅允许访问工作区 ${rootPrefix}` }
      const content = toStr(args, 'content')
      mkdirSync(dirname(path), { recursive: true })
      const tmp = `${path}.${process.pid}.tmp`
      writeFileSync(tmp, content, 'utf8')
      renameSync(tmp, path)
      return { ok: true, output: `已写入 ${rel}（${statSync(path).size} 字节）` }
    },
  }
}

function makeDbQuery(): Tool {
  return {
    schema: {
      name: 'db_query',
      description: '查询模拟数据库（表：users/products/orders）。仅支持 SELECT ... FROM <table> [WHERE k=v] [LIMIT n]。',
      parameters: {
        type: 'object',
        properties: { sql: { type: 'string', description: 'SQL 语句，如 "SELECT * FROM users WHERE city=北京"' } },
        required: ['sql'],
      },
    },
    async run(args) {
      const sql = toStr(args, 'sql')
      const output = fakeQuery(sql)
      return { ok: true, output: `[simulated-db]\n${output}` }
    },
  }
}

/** 创建工具集：注册所有工具，requireApproval 名单决定哪些工具需确认。 */
export function createTools(enabled: string[], requireApproval: string[]): ToolRegistry {
  const registry = new ToolRegistry()
  const all: Tool[] = [makeCalculator(), makeWebSearch(), makeWeather(), makeFileRead(), makeFileWrite(), makeDbQuery()]
  for (const tool of all) {
    if (enabled.includes(tool.schema.name)) {
      if (requireApproval.includes(tool.schema.name)) tool.schema.requiresApproval = true
      registry.register(tool)
    }
  }
  return registry
}

/**
 * 并行执行一批工具调用并聚合结果。
 * 每个调用：先查权限（requiresApproval → askApproval），拒绝则返回 denied 结果。
 */
export async function executeCalls(
  registry: ToolRegistry,
  calls: Array<{ id: string; name: string; arguments: string }>,
  ctx: ToolContext,
  askApproval: (name: string, args: Record<string, unknown>) => Promise<boolean>,
): Promise<Array<{ callId: string; name: string; result: ToolResult }>> {
  const results = await Promise.all(
    calls.map(async (call) => {
      const args = parseArgsSafe(call.arguments)
      if (registry.requiresApproval(call.name)) {
        const approved = await askApproval(call.name, args)
        if (!approved) return { callId: call.id, name: call.name, result: { ok: false, denied: true, output: `用户拒绝了 ${call.name} 的执行` } }
      }
      const result = await registry.execute(call.name, args, ctx)
      return { callId: call.id, name: call.name, result }
    }),
  )
  return results
}

function parseArgsSafe(raw: string): Record<string, unknown> {
  try {
    return JSON.parse(raw) as Record<string, unknown>
  } catch {
    return {}
  }
}
