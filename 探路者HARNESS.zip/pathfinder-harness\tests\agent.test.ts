/**
 * agent.test.ts —— 核心循环 + 集成测试
 * 覆盖：工具选择与结果、规划驱动执行、反思日志、显式记忆、记忆注入、LLM 错误优雅降级、中断。
 */

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Session, type Message } from '../src/session.ts'
import { MemoryStore } from '../src/memory.ts'
import { createTools } from '../src/tools.ts'
import { runTurn, buildSystemPrompt, type AgentHooks } from '../src/agent.ts'
import { MockLlm } from '../src/llm.ts'
import type { AgentConfig, LlmConfig } from '../src/config.ts'

function makeConfig(): AgentConfig {
  return {
    persona: '你是测试 Agent。',
    llm: { provider: 'mock', model: 'mock', baseURL: '', apiKeyEnv: 'auto', maxTokens: 2048, timeoutMs: 5000, temperature: 0 },
    tools: { enabled: ['calculator', 'weather', 'file_read', 'file_write', 'db_query'], requireApproval: ['file_write'], workspaceRoot: './workspace' },
    planning: { enabled: true, maxSteps: 10, maxReplans: 2 },
    reflection: { enabled: true, maxCorrections: 1 },
    memory: { enabled: true, inject: true, maxInjectedItems: 10, shortTermTurns: 8, maxNoteBytes: 8192 },
    context: { tokenBudget: 8000, summarizeThreshold: 0.7, maxSummarizeRetries: 1 },
    persistence: { dir: './data' },
    server: { host: '127.0.0.1', port: 3088 },
  }
}

const MOCK_LLM: LlmConfig = { provider: 'mock', baseURL: '', apiKey: undefined, model: 'mock', maxTokens: 2048, timeoutMs: 5000, temperature: 0 }

function silentHooks(extra?: Partial<AgentHooks>): AgentHooks {
  return { onEvent: () => {}, onDelta: () => {}, askApproval: async () => true, ...extra }
}

async function run(task: string, mockLlm: MockLlm, opts?: { signal?: AbortSignal; onDelta?: (t: string) => void; memory?: MemoryStore }) {
  const config = makeConfig()
  const memory = opts?.memory ?? new MemoryStore(mkdtempSync(join(tmpdir(), 'sa-agent-')), { maxNoteBytes: 8192 })
  const tools = createTools(config.tools.enabled, config.tools.requireApproval)
  const session = new Session({ version: 1, id: 's-test', createdAt: Date.now() })
  session.append('user', [{ type: 'text', text: task }], { kind: 'user' })
  const hooks = silentHooks(opts?.onDelta ? { onDelta: opts.onDelta } : {})
  const result = await runTurn({ session, config, llm: MOCK_LLM, tools, memory, hooks, signal: opts?.signal, mockLlm, persist: () => {}, workspaceRoot: tmpdir() })
  return { session, memory, result, tools }
}

test('核心循环：正确选择工具并返回结果', async () => {
  const mock = new MockLlm([
    { match: '分步计划', content: JSON.stringify({ steps: [{ id: 1, title: '计算', tool: 'calculator', priority: 1, status: 'pending' }] }) },
    { match: '算', toolCalls: [{ id: 'c1', name: 'calculator', arguments: '{"expression":"1+2"}' }] },
    { content: '计算结果是 3', chunkSize: 5 },
  ])
  const { session, result } = await run('帮我算一下 1+2', mock)
  assert.equal(result.text, '计算结果是 3')
  const toolMsg = session.messages.find((m) => m.role === 'tool')
  assert.ok(toolMsg)
  assert.match((toolMsg!.content[0] as { content: string }).content, /1\+2 = 3/)
  assert.equal(result.interrupted, false)
})

test('规划：复杂请求拆解为多步骤并逐步执行', async () => {
  const mock = new MockLlm([
    {
      match: '分步计划',
      content: JSON.stringify({
        steps: [
          { id: 1, title: '查天气', tool: 'weather', priority: 1, status: 'pending' },
          { id: 2, title: '汇总', tool: null, priority: 2, status: 'pending' },
        ],
      }),
    },
    { match: '天气', toolCalls: [{ id: 'c1', name: 'weather', arguments: '{"city":"北京"}' }] },
    { content: '北京天气已查到' },
  ])
  const { session, result } = await run('先查一下北京天气，然后汇总', mock)
  assert.equal(result.text, '北京天气已查到')
  assert.ok(result.plan && result.plan.steps.length === 2)
  assert.ok(session.messages.some((m) => m.role === 'tool'))
})

test('反思：每次行动后写入反思日志', async () => {
  const mock = new MockLlm([
    { match: '分步计划', content: JSON.stringify({ steps: [{ id: 1, title: '计算', tool: 'calculator', priority: 1, status: 'pending' }] }) },
    { match: '算', toolCalls: [{ id: 'c1', name: 'calculator', arguments: '{"expression":"2*3"}' }] },
    { content: '完成' },
  ])
  const { memory, session } = await run('算一下 2*3', mock)
  const reflections = memory.listReflections(session.header.id)
  assert.ok(reflections.length >= 1)
  assert.equal(reflections[0]!.action, 'calculator')
  assert.equal(reflections[0]!.ok, true)
})

test('显式记忆：用户说「记住…」时写入长期记忆', async () => {
  const mock = new MockLlm([{ content: '好的，我记住了。', chunkSize: 4 }])
  const { memory } = await run('记住我喜欢喝咖啡', mock)
  assert.match(memory.getPrompt(), /我喜欢喝咖啡/)
})

test('buildSystemPrompt：包含 persona + 记忆块', () => {
  const prompt = buildSystemPrompt('你是助手', '<memory>\n- [事实] 用户在北京\n</memory>', '')
  assert.match(prompt, /你是助手/)
  assert.match(prompt, /用户在北京/)
})

test('优雅降级：LLM 异常时返回降级提示而非崩溃', async () => {
  const bad = { complete: async () => { throw new Error('network down') } } as unknown as MockLlm
  const { result } = await run('你好', bad)
  assert.match(result.text, /降级模式/)
})

test('中断：流式中途 abort 返回 interrupted', async () => {
  const mock = new MockLlm([
    { match: '分步计划', content: JSON.stringify({ steps: [{ id: 1, title: '回答', tool: null, priority: 1, status: 'pending' }] }) },
    { content: '这是一段很长的流式回复'.repeat(20), chunkSize: 4 },
  ])
  const controller = new AbortController()
  let received = 0
  const { result } = await run('请说一段很长的话', mock, {
    signal: controller.signal,
    onDelta: () => {
      received++
      if (received >= 3) controller.abort()
    },
  })
  assert.equal(result.interrupted, true)
})

test('多轮对话：会话上下文保留（消息数量递增）', async () => {
  const config = makeConfig()
  const memory = new MemoryStore(mkdtempSync(join(tmpdir(), 'sa-agent2-')), { maxNoteBytes: 8192 })
  const tools = createTools(config.tools.enabled, config.tools.requireApproval)
  const session = new Session({ version: 1, id: 's-multi', createdAt: Date.now() })
  const mock = new MockLlm([{ content: '收到', chunkSize: 3 }])
  session.append('user', [{ type: 'text', text: '第一轮' }], { kind: 'user' })
  await runTurn({ session, config, llm: MOCK_LLM, tools, memory, hooks: silentHooks(), mockLlm: mock, persist: () => {}, workspaceRoot: tmpdir() })
  session.append('user', [{ type: 'text', text: '第二轮' }], { kind: 'user' })
  await runTurn({ session, config, llm: MOCK_LLM, tools, memory, hooks: silentHooks(), mockLlm: mock, persist: () => {}, workspaceRoot: tmpdir() })
  const userCount = session.messages.filter((m) => m.role === 'user').length
  const assistantCount = session.messages.filter((m) => m.role === 'assistant').length
  assert.equal(userCount, 2)
  assert.equal(assistantCount, 2)
})
