/**
 * server —— HTTP + SSE 服务器（对应 DSH: web-app 的最简版）。
 *
 * API:
 *   GET  /                  静态资源（web/）
 *   GET  /api/state         会话/记忆文本/反思/计划/供应商/设置 汇总（监控）
 *   GET  /api/memory        { prompt } 单篇记忆文本
 *   POST /api/memory        {action:'save', text} | {action:'clear'} 编辑记忆
 *   GET  /api/providers     供应商列表 + 当前设置
 *   POST /api/providers     {action:'add', provider} | {action:'remove', id} 供应商管理
 *   POST /api/settings      {workspace?, providerId?, model?, temperature?, maxTokens?} 运行设置
 *   POST /api/chat          {sessionId?, message} → SSE 流式
 *   POST /api/stop          {sessionId} → 中断
 *   POST /api/feedback      {sessionId, messageId, rating, note?} → 反馈 + 偏好提取
 *   POST /api/clear|reset   {sessionId} → 清上下文/重置会话
 */

import { createServer, type IncomingMessage, type ServerResponse } from 'node:http'
import { readFileSync, existsSync } from 'node:fs'
import { join, extname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { SessionStore, textOf } from './session.ts'
import { createTools } from './tools.ts'
import { MemoryStore, extractPreferenceFromNote, extractFactsFromMessage } from './memory.ts'
import { runTurn, type AgentHooks, type AgentEvent } from './agent.ts'
import { loadAgentConfig, resolveDataDir, resolveWorkspaceRoot, type AgentConfig } from './config.ts'
import { MockLlm, demoMockScript } from './llm.ts'
import { RuntimeStore, type ProviderDef } from './runtime.ts'
import type { Plan } from './planner.ts'

const WEB_DIR = join(fileURLToPath(new URL('..', import.meta.url)), 'web')

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
}

export interface ServerOptions {
  port: number
  mock: boolean
}

export interface RuntimeState {
  config: AgentConfig
  store: SessionStore
  memory: MemoryStore
  runtime: RuntimeStore
  abortControllers: Map<string, AbortController>
  lastPlans: Map<string, Plan>
  running: Map<string, boolean>
}

function json(res: ServerResponse, code: number, body: unknown): void {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' })
  res.end(JSON.stringify(body))
}

function readBody(req: IncomingMessage): Promise<Record<string, unknown>> {
  return new Promise((resolve, reject) => {
    let data = ''
    req.on('data', (chunk) => {
      data += chunk
      if (data.length > 1e6) req.destroy()
    })
    req.on('end', () => {
      try {
        resolve(data.trim() === '' ? {} : (JSON.parse(data) as Record<string, unknown>))
      } catch (error) {
        reject(error)
      }
    })
    req.on('error', reject)
  })
}

function sse(res: ServerResponse): void {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  })
}

function sseSend(res: ServerResponse, event: string, data: unknown): void {
  res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`)
}

export async function startServer(configOverride?: AgentConfig, opts?: ServerOptions): Promise<import('node:http').Server> {
  const config = configOverride ?? loadAgentConfig()
  const port = opts?.port ?? config.server.port
  const mock = opts?.mock ?? false
  const dataDir = resolveDataDir(config)
  const state: RuntimeState = {
    config,
    store: new SessionStore(dataDir),
    memory: new MemoryStore(dataDir, { maxNoteBytes: config.memory.maxNoteBytes }),
    runtime: new RuntimeStore(dataDir),
    abortControllers: new Map(),
    lastPlans: new Map(),
    running: new Map(),
  }
  const tools = createTools(config.tools.enabled, config.tools.requireApproval)

  /** 每请求动态解析 LLM 与工作区（用户可在运行中改供应商/工作区）。 */
  const resolvePerRequest = () => {
    const llm = state.runtime.resolveLlm(config, mock)
    const workspaceRoot = state.runtime.resolveWorkspace(resolveWorkspaceRoot(config))
    return { llm, workspaceRoot }
  }

  const server = createServer(async (req, res) => {
    const url = new URL(req.url ?? '/', 'http://localhost')
    const path = url.pathname
    const method = req.method ?? 'GET'

    try {
      // ---- 静态资源 ----
      if (method === 'GET' && (path === '/' || path === '/index.html')) {
        res.writeHead(200, { 'Content-Type': MIME['.html'] })
        res.end(readFileSync(join(WEB_DIR, 'index.html')))
        return
      }
      if (method === 'GET' && (path === '/style.css' || path === '/app.js')) {
        const file = join(WEB_DIR, path === '/style.css' ? 'style.css' : 'app.js')
        if (!existsSync(file)) {
          res.writeHead(404)
          res.end('not found')
          return
        }
        res.writeHead(200, { 'Content-Type': MIME[extname(file)] ?? 'application/octet-stream' })
        res.end(readFileSync(file))
        return
      }

      // ---- 状态汇总 ----
      if (method === 'GET' && path === '/api/state') {
        const settings = state.runtime.loadSettings()
        const { llm } = resolvePerRequest()
        const sessions = state.store.list().map((id) => {
          const s = state.store.load(id)
          return {
            id,
            messages: s?.messages.length ?? 0,
            last: s ? [...s.messages].reverse().find((m) => m.role === 'assistant' || m.role === 'user') : undefined,
            running: state.running.get(id) ?? false,
            plan: state.lastPlans.get(id) ?? null,
          }
        })
        json(res, 200, {
          sessions,
          memory: { prompt: state.memory.getPrompt() },
          feedback: [...state.memory.listAllFeedback().entries()].map(([sid, items]) => ({ sessionId: sid, items })),
          reflections: [...state.store.list()].map((id) => ({ sessionId: id, entries: state.memory.listReflections(id) })),
          providers: state.runtime.listProviders().map((p) => ({ ...p, apiKey: p.apiKey ? '••••' + p.apiKey.slice(-4) : '' })),
          settings,
          workspace: state.runtime.resolveWorkspace(resolveWorkspaceRoot(config)),
          model: { provider: llm.provider, model: llm.model },
          config: { temperature: settings.temperature, maxTokens: settings.maxTokens, tokenBudget: config.context.tokenBudget },
        })
        return
      }

      // ---- 记忆（单篇文本） ----
      if (method === 'GET' && path === '/api/memory') {
        json(res, 200, { prompt: state.memory.getPrompt() })
        return
      }
      if (method === 'POST' && path === '/api/memory') {
        const body = await readBody(req)
        const action = String(body.action ?? '')
        if (action === 'save') {
          const text = String(body.text ?? '')
          state.memory.setPrompt(text)
          json(res, 200, { ok: true, prompt: state.memory.getPrompt() })
          return
        }
        if (action === 'clear') {
          state.memory.clear()
          json(res, 200, { ok: true, prompt: '' })
          return
        }
        json(res, 400, { error: '未知 action（支持 save / clear）' })
        return
      }

      // ---- 供应商 ----
      if (method === 'GET' && path === '/api/providers') {
        json(res, 200, {
          providers: state.runtime.listProviders().map((p) => ({ ...p, apiKey: p.apiKey ? '••••' + p.apiKey.slice(-4) : '' })),
          settings: state.runtime.loadSettings(),
        })
        return
      }
      if (method === 'POST' && path === '/api/providers') {
        const body = await readBody(req)
        const action = String(body.action ?? '')
        if (action === 'add') {
          const p = body.provider as Record<string, unknown> | undefined
          if (!p || typeof p.id !== 'string' || p.id.trim() === '') {
            json(res, 400, { error: 'Provider ID 不能为空' })
            return
          }
          const def: ProviderDef = {
            id: p.id.trim().toLowerCase(),
            displayName: String(p.displayName ?? p.id),
            baseURL: String(p.baseURL ?? '').replace(/\/+$/, ''),
            protocol: String(p.protocol ?? 'openai-completions'),
            apiKey: String(p.apiKey ?? ''),
            models: Array.isArray(p.models) ? p.models.map(String).filter((m) => m !== '') : [],
            model: String(p.model ?? ''),
            createdAt: Date.now(),
          }
          const entry = state.runtime.addProvider(def)
          // 首次添加或未设默认时自动设为当前供应商
          const settings = state.runtime.loadSettings()
          if (!settings.providerId) state.runtime.saveSettings({ ...settings, providerId: entry.id, model: entry.model || entry.models[0] || settings.model })
          json(res, 200, { ok: true, provider: { ...entry, apiKey: entry.apiKey ? '••••' + entry.apiKey.slice(-4) : '' } })
          return
        }
        if (action === 'remove') {
          const id = String(body.id ?? '')
          const removed = state.runtime.removeProvider(id)
          json(res, 200, { ok: true, removed })
          return
        }
        json(res, 400, { error: '未知 action（支持 add / remove）' })
        return
      }

      // ---- 运行设置（工作区/供应商/模型/温度/token） ----
      if (method === 'POST' && path === '/api/settings') {
        const body = await readBody(req)
        const settings = state.runtime.loadSettings()
        if (typeof body.workspace === 'string') settings.workspace = body.workspace
        if (typeof body.providerId === 'string') settings.providerId = body.providerId
        if (typeof body.model === 'string') settings.model = body.model
        if (typeof body.temperature === 'number') settings.temperature = body.temperature
        if (typeof body.maxTokens === 'number') settings.maxTokens = body.maxTokens
        state.runtime.saveSettings(settings)
        json(res, 200, { ok: true, settings })
        return
      }

      // ---- 历史消息 ----
      if (method === 'GET' && path === '/api/history') {
        const id = url.searchParams.get('id') ?? ''
        const session = state.store.load(id)
        if (!session) {
          json(res, 404, { error: '会话不存在' })
          return
        }
        const messages = session.messages.map((m) => ({
          id: m.id,
          role: m.role,
          text: textOf(m),
          createdAt: m.createdAt,
        }))
        json(res, 200, { messages })
        return
      }

      // ---- 聊天（SSE 流式） ----
      if (method === 'POST' && path === '/api/chat') {
        const body = await readBody(req)
        const message = typeof body.message === 'string' ? body.message : ''
        const sessionId = typeof body.sessionId === 'string' && body.sessionId !== '' ? body.sessionId : undefined
        if (message === '') {
          json(res, 400, { error: 'message 不能为空' })
          return
        }
        if (sessionId && state.running.get(sessionId)) {
          json(res, 409, { error: '该会话已有进行中的请求' })
          return
        }
        let session = sessionId ? state.store.load(sessionId) : undefined
        if (sessionId && !session) {
          json(res, 404, { error: '会话不存在' })
          return
        }
        if (!session) session = state.store.create(process.cwd())
        const sid = session.header.id
        const persist = () => state.store.save(session!)
        session.append('user', [{ type: 'text', text: message }], { kind: 'user' })
        persist()

        for (const fact of extractFactsFromMessage(message)) state.memory.addMemory('fact', fact, sid, 'user-explicit')

        const controller = new AbortController()
        state.abortControllers.set(sid, controller)
        state.running.set(sid, true)
        sse(res)

        const hooks: AgentHooks = {
          onEvent: (ev: AgentEvent) => {
            if (ev.type === 'plan/created') state.lastPlans.set(sid, ev.detail as Plan)
            sseSend(res, 'event', ev)
          },
          onDelta: (text) => {
            sseSend(res, 'delta', { text })
          },
          askApproval: async (name, args) => {
            sseSend(res, 'approval', { name, args })
            return true
          },
        }

        // 每请求动态解析（支持运行中切换供应商/工作区）
        const { llm, workspaceRoot } = resolvePerRequest()
        const mockLlm = mock || llm.provider === 'mock' ? new MockLlm(demoMockScript()) : undefined

        try {
          const result = await runTurn({ session, config, llm, tools, memory: state.memory, hooks, signal: controller.signal, persist, workspaceRoot, mockLlm })
          sseSend(res, 'done', { text: result.text, steps: result.steps, interrupted: result.interrupted, plan: state.lastPlans.get(sid) ?? null })
        } catch (error) {
          sseSend(res, 'error', { error: error instanceof Error ? error.message : String(error) })
        } finally {
          state.running.set(sid, false)
          state.abortControllers.delete(sid)
          res.end()
        }
        return
      }

      // ---- 中断 ----
      if (method === 'POST' && path === '/api/stop') {
        const body = await readBody(req)
        const sessionId = typeof body.sessionId === 'string' ? body.sessionId : undefined
        if (!sessionId) {
          json(res, 400, { error: 'sessionId 缺失' })
          return
        }
        const controller = state.abortControllers.get(sessionId)
        if (controller) {
          controller.abort()
          json(res, 200, { ok: true })
        } else {
          json(res, 200, { ok: false, message: '无进行中的请求' })
        }
        return
      }

      // ---- 反馈 ----
      if (method === 'POST' && path === '/api/feedback') {
        const body = await readBody(req)
        const sessionId = String(body.sessionId ?? '')
        const messageId = String(body.messageId ?? '')
        const rating = body.rating === 'up' || body.rating === 'positive' ? 'positive' : 'negative'
        const note = typeof body.note === 'string' ? body.note : undefined
        if (!sessionId || !messageId) {
          json(res, 400, { error: 'sessionId/messageId 缺失' })
          return
        }
        const session = state.store.load(sessionId)
        let target = session?.find(messageId)
        if (messageId === 'last') {
          target = [...(session?.messages ?? [])].reverse().find((m) => m.role === 'assistant')
        }
        if (!session || !target || target.role !== 'assistant') {
          json(res, 404, { error: '目标消息不存在或不是助手消息' })
          return
        }
        const finalMessageId = target.id
        const existing = state.memory.getFeedback(sessionId, finalMessageId)
        const result = state.memory.putFeedback(sessionId, { messageId: finalMessageId, rating, note, ifVersion: existing?.version ?? null })
        if (!result.ok) {
          json(res, 409, result)
          return
        }
        let preference: string | undefined
        if (note && note.trim() !== '') {
          preference = extractPreferenceFromNote(note, rating)
          if (preference) state.memory.addMemory('preference', preference, sessionId, 'feedback')
        } else if (rating === 'negative') {
          preference = '用户对这类回答不满意（未注明原因），应避免重复'
          state.memory.addMemory('preference', preference, sessionId, 'feedback')
        }
        json(res, 200, { ok: true, item: result.item, preference })
        return
      }

      // ---- 清空/重置上下文 ----
      if (method === 'POST' && (path === '/api/clear' || path === '/api/reset')) {
        const body = await readBody(req)
        const sessionId = String(body.sessionId ?? '')
        const session = state.store.load(sessionId)
        if (!session) {
          json(res, 404, { error: '会话不存在' })
          return
        }
        if (path === '/api/reset') session.reset()
        else session.clearContext(2)
        state.store.save(session)
        json(res, 200, { ok: true, messages: session.messages.length })
        return
      }

      json(res, 404, { error: 'not found' })
    } catch (error) {
      json(res, 500, { error: error instanceof Error ? error.message : String(error) })
    }
  })

  await new Promise<void>((resolve) => server.listen(port, config.server.host, resolve))
  const { llm } = resolvePerRequest()
  process.stderr.write(`[探路者HARNESS] 控制台已启动: http://${config.server.host}:${port}  (llm=${llm.provider}/${llm.model}${mock ? ' mock' : ''})\n`)
  return server
}
