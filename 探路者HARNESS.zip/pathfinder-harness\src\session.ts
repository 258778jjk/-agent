/**
 * session —— 会话与持久化（对应 DSH: dsh-session + dsh-session-persistence-jsonl）。
 *
 * 会话是消息日志：每条消息有 seq/id/role/ContentBlock/时间戳/来源。
 * 持久化 append-only JSONL：首行 header + 每行一条消息。
 * 支持：追加、恢复、上下文清理（保留最近 N 条）、重置。
 */

import { randomUUID } from 'node:crypto'
import { mkdirSync, readFileSync, writeFileSync, existsSync, readdirSync } from 'node:fs'
import { join } from 'node:path'

export interface TextBlock {
  type: 'text'
  text: string
}

export interface ToolCallBlock {
  type: 'tool-call'
  id: string
  name: string
  arguments: string
}

export interface ToolResultBlock {
  type: 'tool-result'
  toolCallId: string
  content: string
  isError?: boolean
}

export type ContentBlock = TextBlock | ToolCallBlock | ToolResultBlock

export type MessageRole = 'user' | 'assistant' | 'tool'

export interface Message {
  id: string
  seq: number
  role: MessageRole
  content: ContentBlock[]
  createdAt: number
  source?: { kind: string; provider?: string; model?: string; toolCallId?: string }
}

export interface SessionHeader {
  version: 1
  id: string
  createdAt: number
  cwd?: string
}

export class Session {
  readonly header: SessionHeader
  readonly messages: Message[]

  constructor(header: SessionHeader, messages: Message[] = []) {
    this.header = header
    this.messages = messages
  }

  get nextSeq(): number {
    return this.messages.length > 0 ? this.messages[this.messages.length - 1]!.seq + 1 : 0
  }

  append(role: MessageRole, content: ContentBlock[], source?: Message['source']): Message {
    const msg: Message = { id: `m-${this.nextSeq}`, seq: this.nextSeq, role, content, createdAt: Date.now(), source }
    this.messages.push(msg)
    return msg
  }

  assistantMessages(): Message[] {
    return this.messages.filter((m) => m.role === 'assistant')
  }

  find(id: string): Message | undefined {
    return this.messages.find((m) => m.id === id)
  }

  /** 推导给模型的对话历史（wire 格式）。 */
  deriveWireMessages(): import('./llm.ts').WireMessage[] {
    const out: import('./llm.ts').WireMessage[] = []
    for (const msg of this.messages) {
      if (msg.role === 'user') {
        out.push({ role: 'user', content: textOf(msg) })
      } else if (msg.role === 'assistant') {
        const toolCalls = msg.content
          .filter((b): b is ToolCallBlock => b.type === 'tool-call')
          .map((b) => ({ id: b.id, type: 'function' as const, function: { name: b.name, arguments: b.arguments } }))
        out.push({ role: 'assistant', content: textOf(msg) || null, ...(toolCalls.length > 0 ? { tool_calls: toolCalls } : {}) })
      } else if (msg.role === 'tool') {
        const block = msg.content.find((b): b is ToolResultBlock => b.type === 'tool-result')
        out.push({ role: 'tool', content: block?.content ?? '', tool_call_id: msg.source?.toolCallId ?? block?.toolCallId ?? '' })
      }
    }
    return out
  }

  /** 手动清除上下文：保留最近 keep 条消息（默认 0 = 全清），生成一条清空标记。 */
  clearContext(keep = 0): void {
    const total = this.messages.length
    if (keep >= total) return
    const kept = this.messages.slice(total - keep)
    this.messages.length = 0
    for (const msg of kept) this.messages.push(msg)
  }

  /** 重置会话：清空全部消息。 */
  reset(): void {
    this.messages.length = 0
  }
}

export function textOf(msg: Message): string {
  return msg.content
    .filter((b): b is TextBlock => b.type === 'text')
    .map((b) => b.text)
    .join('')
}

/** SessionStore —— data/sessions/<id>/session.jsonl。 */
export class SessionStore {
  readonly root: string

  constructor(root: string) {
    this.root = root
    mkdirSync(join(root, 'sessions'), { recursive: true })
  }

  private dirFor(id: string): string {
    return join(this.root, 'sessions', id)
  }

  private fileFor(id: string): string {
    return join(this.dirFor(id), 'session.jsonl')
  }

  create(cwd: string): Session {
    const id = `session-${randomUUID()}`
    mkdirSync(this.dirFor(id), { recursive: true })
    const session = new Session({ version: 1, id, createdAt: Date.now(), cwd })
    this.save(session)
    return session
  }

  save(session: Session): void {
    const lines = [JSON.stringify({ type: 'session', ...session.header })]
    for (const msg of session.messages) lines.push(JSON.stringify({ type: 'message', ...msg }))
    writeFileSync(this.fileFor(session.header.id), lines.join('\n') + '\n', 'utf8')
  }

  load(id: string): Session | undefined {
    const file = this.fileFor(id)
    if (!existsSync(file)) return undefined
    let header: SessionHeader | undefined
    const messages: Message[] = []
    for (const line of readFileSync(file, 'utf8').split(/\r?\n/)) {
      if (line.trim() === '') continue
      try {
        const rec = JSON.parse(line) as { type: string; [k: string]: unknown }
        if (rec.type === 'session') {
          header = { version: 1, id: String(rec.id), createdAt: Number(rec.createdAt), cwd: rec.cwd as string | undefined }
        } else if (rec.type === 'message') {
          messages.push(rec as unknown as Message)
        }
      } catch {
        // 跳过损坏行
      }
    }
    if (!header) return undefined
    return new Session(header, messages)
  }

  list(): string[] {
    const dir = join(this.root, 'sessions')
    if (!existsSync(dir)) return []
    return readdirSync(dir, { withFileTypes: true })
      .filter((d) => d.isDirectory() && d.name.startsWith('session-'))
      .map((d) => d.name)
  }
}
